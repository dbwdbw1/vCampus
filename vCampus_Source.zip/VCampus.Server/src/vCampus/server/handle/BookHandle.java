package vCampus.server.handle;

import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.common.baseClass.Book;
import vCampus.server.dao.IBookDao;

public class BookHandle {

	private Message message;
	
	private IBookDao iBookDao;
	
	private ObjectMapper mapper;
	
	public BookHandle(){
		
	}
	
	public BookHandle(Message message){
		
		this.message = message;
		this.iBookDao = new IBookDao();
		this.mapper = new ObjectMapper();
				
	}
	
	public String handle(){
		String result = null;
		
		switch (message.getName()) {
		case "list":
			try {
				result = list(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		case "select":
			try {
				result = select(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		case "retreat":
			try {
				result = retreat(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		default:
			break;
		}
		
		return result;
	}
	
	private String list(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{	
		Book[] bookList= iBookDao.list(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class));
		String json = mapper.writeValueAsString(bookList);
		return json;
	}
	
	private String select(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iBookDao.select(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), hashMap.get("bookId").toString());
		return result.toString();
	}
	
	private String retreat(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iBookDao.retreat(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), hashMap.get("bookId").toString());
		return result.toString();
	}
}
