package vCampus.server.handle;

import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.Student;
import vCampus.common.baseClass.User;
import vCampus.server.dao.IStudentDao;

public class StudentHandle {
	
	private Message message;
	
	private IStudentDao iStudentDao;
	
	private ObjectMapper mapper;
	
	public StudentHandle(){
		
	}
	
	public StudentHandle(Message message){
		this.message = message;
		iStudentDao = new IStudentDao();
		this.mapper = new ObjectMapper();
	}
	
	public String handle(){
		
		String result = null;
		
		switch (message.getName()) {
		case "list":
			try {
				result = list(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		case "add":
			try {
				result = add(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		case "delete":
			try {
				result = delete(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		case "update":
			try {
				result = update(message.getData());
			} catch (Exception e) {
				result = null;
				e.printStackTrace();
			}
			break;
		default:
			result = null;
			break;
		}
		
		return result;
	}
	
	private String list(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Student[] students= iStudentDao.list(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class));
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(students);
		return json;
	}
	
	private String add(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iStudentDao.add(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), mapper.readValue(mapper.writeValueAsString(hashMap.get("student")), Student.class));
		return result.toString();
	}
	
	private String delete(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iStudentDao.delete(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), hashMap.get("studentId").toString());
		return result.toString();
	}
	
	private String update(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iStudentDao.update(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), mapper.readValue(mapper.writeValueAsString(hashMap.get("student")), Student.class));
		return result.toString();
	}
}
