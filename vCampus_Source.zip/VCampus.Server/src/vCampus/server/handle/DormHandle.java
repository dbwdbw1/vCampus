package vCampus.server.handle;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Dorm;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.server.dao.IDormDao;

public class DormHandle {
	private Message message;
	private IDormDao iDormDao;
	private ObjectMapper mapper;
	
	public DormHandle(){
		
	}
	
	public DormHandle(Message message){
		this.message = message;
		iDormDao = new IDormDao();
		this.mapper = new ObjectMapper();
	}
	
	public String handle(){
		
		String result = null;
		
		switch (message.getName()) {
		case "list":
			try {
				result = list();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		default:
			result = null;
			break;
		}
		return result ;
	}
	
	private String list() throws Exception{
		
		Dorm[] dorms= iDormDao.list(mapper.readValue(mapper.writeValueAsString(message.getData().get("user")), User.class));
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(dorms);
		return json;
	}
}
