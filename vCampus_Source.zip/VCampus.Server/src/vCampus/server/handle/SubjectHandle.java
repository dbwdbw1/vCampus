package vCampus.server.handle;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.Subject;
import vCampus.common.baseClass.User;
import vCampus.server.dao.ISubjectDao;

public class SubjectHandle {
	private Message message;
	private ISubjectDao iSubjectDao;
	private ObjectMapper mapper;
	
	public SubjectHandle(){
		
	}
	
	public SubjectHandle(Message message){
		this.message = message;
		this.iSubjectDao = new ISubjectDao();
		this.mapper = new ObjectMapper();
	}
	
	public String handle() {
		String result = null;
		
		switch (message.getName()) {
		case "list":
			try {
				result = list();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "select":
			try {
				result = select();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "retreat":
			try {
				result = retreat();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "add":
			try {
				result = add();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "delete":
			try {
				result = delete();
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		default:
			result = null;
			break;
		}
		
		return result;
	}
	
	private String list() throws Exception {
		Subject[] subjects= iSubjectDao.list(mapper.readValue(mapper.writeValueAsString(message.getData().get("user")), User.class));
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(subjects);
		return json;
	}
	
	private String select() throws Exception {
		Boolean result = iSubjectDao.select(mapper.readValue(mapper.writeValueAsString(message.getData().get("user")), User.class), message.getData().get("subjectId").toString());
		return result.toString();
	}
	
	private String retreat() throws Exception {
		Boolean result = iSubjectDao.retreat(mapper.readValue(mapper.writeValueAsString(message.getData().get("user")), User.class), message.getData().get("subjectId").toString());
		return result.toString();
	}
	
	private String add() throws Exception{
		Boolean result = iSubjectDao.add(mapper.readValue(mapper.writeValueAsString(message.getData().get("user")), User.class), mapper.readValue(mapper.writeValueAsString(message.getData().get("subject")), Subject.class));
		return result.toString();
	}
	
	private String delete() throws Exception{
		Boolean result = iSubjectDao.delete(mapper.readValue(mapper.writeValueAsString(message.getData().get("user")), User.class), message.getData().get("subjectId").toString());
		return result.toString();
	}
}
