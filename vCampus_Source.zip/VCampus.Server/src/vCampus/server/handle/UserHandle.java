package vCampus.server.handle;

import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.server.dao.IUserDao;

public class UserHandle {
	
	private Message message;
	
	private IUserDao iUserDao;
	
	public UserHandle(){
		
	}
	
	public UserHandle(Message message){
		this.message = message;
		this.iUserDao = new IUserDao();
		new ObjectMapper();
	}
	
	public String handle(){
		String result = null;
		switch (message.getName()){
			
			case "login":
			try {
				result = login(message.getData());
			} catch (Exception e1) {
				e1.printStackTrace();
			}
			break;
			
			case "register":
			try{
				result = register(message.getData());
			}
			catch (Exception e) {
				e.printStackTrace();
				result = null;
			}
			break;	
			
			default:
			result = null;
		}
		return result;
	}
	
	private String login(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
			
		ObjectMapper mapper = new ObjectMapper();
		
		User user = iUserDao.login(hashMap.get("id").toString(), hashMap.get("password").toString());
		
		String json = mapper.writeValueAsString(user);
		System.out.println(json);
		return json;
	}
	
	private String register(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		ObjectMapper mapper = new ObjectMapper();
		User user = mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class);
		//Boolean result = iUserDao.register((User)hashMap.get("user"));
		Boolean result = iUserDao.register(user);
		return result.toString();
	}
}
