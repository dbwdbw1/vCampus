package vCampus.server.handle;

import java.util.HashMap;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Commodity;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.server.dao.ICommodityDao;

public class CommodityHandle {
	private Message message;
	
	private ICommodityDao iCommodityDao;
	
	private ObjectMapper mapper;
	
	public CommodityHandle(){
		
	}
	
	public CommodityHandle(Message message){
		this.message = message;
		iCommodityDao = new ICommodityDao();
		this.mapper = new ObjectMapper();
	}
	
	public String handle(){
		String result = null;
		
		switch (message.getName()) {
		case "list":
			try {
				result = list(message.getData());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "purchase":
			try {
				result = purchase(message.getData());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "charge":
			try {
				result = charge(message.getData());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "add":
			try {
				result = add(message.getData());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		case "delete":
			try {
				result = delete(message.getData());
			} catch (Exception e) {
				e.printStackTrace();
			}
			break;
		default:
			result = null;
			break;
		}
		
		return result;
	}
	
	private String list(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Commodity[] commodities= iCommodityDao.list(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class));
		ObjectMapper mapper = new ObjectMapper();
		String json = mapper.writeValueAsString(commodities);
		return json;
	}
	
	private String purchase(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iCommodityDao.purchase(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), hashMap.get("commodityId").toString(), Integer.parseInt(hashMap.get("count").toString()));
		return result.toString();
	}
	
	private String charge(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iCommodityDao.charge(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), Integer.parseInt(hashMap.get("amount").toString()));
		return result.toString();
	}
	
	public String add(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception{
		
		Boolean result = iCommodityDao.add(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), mapper.readValue(mapper.writeValueAsString(hashMap.get("commodity")), Commodity.class));
		return result.toString();
	}
	
	public String delete(@SuppressWarnings("rawtypes") HashMap hashMap) throws Exception {
		Boolean result = iCommodityDao.delete(mapper.readValue(mapper.writeValueAsString(hashMap.get("user")), User.class), hashMap.get("commodityId").toString());
		return result.toString();
	}
}
