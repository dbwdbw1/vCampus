package vCampus.server.socket;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;

import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Message;
import vCampus.server.handle.BookHandle;
import vCampus.server.handle.CommodityHandle;
import vCampus.server.handle.DormHandle;
import vCampus.server.handle.StudentHandle;
import vCampus.server.handle.SubjectHandle;
import vCampus.server.handle.UserHandle;

public class MessageSrv extends Thread{

	private Socket socket;

	public MessageSrv(Socket socket) {
		this.socket = socket;
	}

	public void run() {
		try {
			handleSocket();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void handleSocket() throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UNICODE"));
		StringBuilder sb = new StringBuilder();
		String temp;
		int index;
		while ((temp = br.readLine()) != null) {
			if ((index = temp.indexOf("eof")) != -1) {  //����eofʱ�ͽ�������
				sb.append(temp.substring(0, index));
				break;
			}
			sb.append(temp);
		}

		ObjectMapper mapper = new ObjectMapper();
		Message message = mapper.readValue(sb.toString(), Message.class);
		String flushData = handleMessage(message);
		Writer writer = new OutputStreamWriter(socket.getOutputStream(), "UNICODE");
		writer.write(flushData);
		writer.write("eof\n");
		writer.flush();
		writer.close();
		br.close();
		socket.close();
	}
	
	private String handleMessage(Message message){
		
		System.out.println("message: " + message.getDomain() + " " + message.getName());
		String result = null;
		switch (message.getDomain()) {
		case "User":
			UserHandle userHandle = new UserHandle(message);
			result = userHandle.handle();
			break;
		case "Student":
			StudentHandle studentHandle =  new StudentHandle(message);
			result = studentHandle.handle();
			break;
		case "Subject":
			SubjectHandle subjectHandle = new SubjectHandle(message);
			result = subjectHandle.handle();
			break;
		case "Book":
			BookHandle bookHandle = new BookHandle(message);
			result = bookHandle.handle();
			break;
		case "Commodity":
			CommodityHandle commodityHandle = new CommodityHandle(message);
			result = commodityHandle.handle();
			break;
		case "Dorm":
			DormHandle dormHandle = new DormHandle(message);
			result = dormHandle.handle();
			break;
		default:
			result = null;
			break;
		}
		
		return result;
		
	}
	
}
