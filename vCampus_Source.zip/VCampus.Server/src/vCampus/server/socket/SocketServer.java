package vCampus.server.socket;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import vCampus.server.thread.ThreadPool;

public class SocketServer {

	private int server_port; // �������˿�
	@SuppressWarnings("unused")
	private int server_status; // ������״̬
	private ServerSocket server;
	private ThreadPool threadpool;

	public SocketServer() {
		server_port = 2333;
		server_status = 0;
		threadpool = new ThreadPool();
	}

	public SocketServer(ThreadPool now_threadpool) {
		server_port = 2333;
		server_status = 0;
		threadpool = now_threadpool;
	}

	public void start() throws IOException { // �½�Socket������������������
		server = new ServerSocket(server_port);
		new Thread() {
			public void run() {
				while (!threadpool.isClosed()) {
					Socket socket;
					try {
						socket = server.accept();
						threadpool.execute(new MessageSrv(socket));
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();
	}

	public void close() throws IOException // �رշ�����
	{
		threadpool.shutdown();
		server.close();
	}

	public void restart() throws IOException { // ����������
		close();
		threadpool = new ThreadPool();
		start();
	}
	
	public static void main(String[] args) {
		SocketServer socketServer = new SocketServer();
		try {
			socketServer.start();
			System.out.println("Server start");
			System.out.println("listen on port:" + Integer.toString(socketServer.server_port));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}