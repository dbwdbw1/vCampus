package vCampus.server.thread;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPool {
	private ExecutorService threadpool;
	public ThreadPool() { //�½��̳߳�
		threadpool = Executors.newCachedThreadPool();
	}
	public void execute(Thread thread)
	{
		threadpool.execute(thread);
	}
	public void shutdown() { //�ر��̳߳�
		threadpool.shutdown();
	}
	public boolean isClosed()
	{
		return threadpool.isShutdown();
	}
}