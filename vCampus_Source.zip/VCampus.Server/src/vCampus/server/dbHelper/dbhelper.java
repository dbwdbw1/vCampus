/*
 * Created on 2016-8-25
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package vCampus.server.dbHelper;

import java.net.URISyntaxException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/**
 * @author C4413
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class dbhelper{
	
	public dbhelper(){
		Connection conn = null;
		try{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String path = null;
			try {
				path = this.getClass().getClassLoader().getResource("vCampus.accdb").toURI().getPath().substring(1);
				System.out.println(path);
			} catch (URISyntaxException e1) {
				e1.printStackTrace();
			}   //��λ���ݿ��ļ���λ��		 
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			conn = DriverManager.getConnection(url);
			conn.createStatement();
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection(){
		Connection conn = null;
		
		String url = "jdbc:odbc:vCampus";
		String user = "";
		String pwd = "";
		try {
			Class.forName("");
			conn = DriverManager.getConnection(url, user, pwd);
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return conn;		
	}
	
}
