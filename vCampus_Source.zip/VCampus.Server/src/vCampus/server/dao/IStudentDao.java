package vCampus.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import vCampus.common.baseClass.Student;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IStudentInterface;

public class IStudentDao implements IStudentInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#list(vCampus.common.baseClass.User)
	 */
	@Override
	public Student[] list(User user) {
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		try {
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
		String sqlStr2 = "select * from tblStudent ";
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);//���û��Ƿ����
			if(!rs1.next())
			{
				return null;
			}
			ResultSet rs2 = stmt.executeQuery(sqlStr2);			
			int count =0;
			while(rs2.next())
			{
				count++;
			}
			Student student[]=new Student[count];
			ResultSet rs21 = stmt.executeQuery(sqlStr2);
			rs21.next();
			for(int i=0;i<count;i++)
			{
				student[i] = new Student();
				student[i].setId(rs21.getString("sid"));
				student[i].setName(rs21.getString("sname"));
				int sgrade = Integer.parseInt(rs21.getString("sgrade"));
				student[i].setGrade(sgrade);
				student[i].setGender(rs21.getString("sgender"));
				student[i].setCollege(rs21.getString("scollege"));
				student[i].setMajor(rs21.getString("smajor"));
				student[i].setPhone(rs21.getString("sphone"));
				rs21.next();
			}
			boolean flag=false;
			if(user.getPower())//�Ƿ����Ա
			{
				flag = true;
			}
			if(flag)
			{
				return student;
			}
			else
			{
				id = user.getId();
				String sqlStr3 = "select * from tblStudent where sid='"+id+"'";
				ResultSet rs3 = stmt.executeQuery(sqlStr3);	
				rs3.next();
				Student student0[] = new Student[1];
				student0[0] = new Student();
				student0[0].setId(rs3.getString("sid"));
				student0[0].setName(rs3.getString("sname"));
				student0[0].setCollege(rs3.getString("scollege"));
				student0[0].setGender(rs3.getString("sgender"));
				student0[0].setGrade(rs3.getInt("sgrade"));
				student0[0].setMajor(rs3.getString("smajor"));
				student0[0].setPhone(rs3.getString("sphone"));
				return student0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#add(vCampus.common.baseClass.User, vCampus.common.baseClass.Student)
	 */
	@Override
	public Boolean add(User user, Student student) {
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try {
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
			ResultSet rs1;
			try {
				rs1 = stmt.executeQuery(sqlStr1);
				if(!rs1.next())
				{
					return false;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}//���û��Ƿ����
			boolean flag = false;
			if(user.getPower())//�Ƿ����Ա
			{
				flag = true;
			}
			if(!flag)
			{
				return false;
			}
			else
			{
				String sqlStr3 = "insert into tblStudent values('"+student.getId()+"','"+student.getName()+"','"+student.getCollege()+"','"+student.getMajor()+"',"+student.getGrade()+",'"+student.getGender()+"','"+student.getPhone()+"')";
				try {
					stmt.executeUpdate(sqlStr3);
					stmt.executeUpdate(sqlStr3);
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				}
			}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#delete(vCampus.common.baseClass.User, java.lang.String)
	 */
	@Override
	public Boolean delete(User user, String id) {
		String sid = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try {
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		String sqlStr1 = "select * from tblUser where uid='"+sid+"'";
			ResultSet rs1;
			try {
				rs1 = stmt.executeQuery(sqlStr1);
				if(!rs1.next())
				{
					return false;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}//���û��Ƿ����
			boolean flag = false;
			if(user.getPower())//�Ƿ����Ա
			{
				flag = true;
			}
			if(!flag)
			{
				return false;
			}
			else
			{
				//�������ݿ�,ɾ��ָ����
				String sqlStr2 = "delete from tblStudent where sid = '"+id+"'";
				try {
					stmt.executeUpdate(sqlStr2);
					stmt.executeUpdate(sqlStr2);
				} catch (SQLException e) {
					e.printStackTrace();
					return false;
				}
			}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#update(vCampus.common.baseClass.User, vCampus.common.baseClass.Student)
	 */
	@Override
	public Boolean update(User user, Student student) {
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try {
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
			ResultSet rs1;
			try {
				rs1 = stmt.executeQuery(sqlStr1);
				if(!rs1.next())
				{
					return false;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}//���û��Ƿ����
			boolean flag = false;
			if(user.getPower())//�Ƿ����Ա
			{
				flag = true;
			}
			if(!flag)//���ǹ���Ա����false
			{
				if(!(user.getId()==student.getId()))
				{
					return false;
				}
			}
			String sqlStr2 = "update tblStudent set sid='"+student.getId()+"',sname='"+student.getName()+"',scollege='"+student.getCollege()+"',smajor='"+student.getMajor()+"',sgrade="+student.getGrade()+",sgender='"+student.getGender()+"',sphone='"+student.getPhone()+"' where sid = '"+id+"'";
			try {
				stmt.executeUpdate(sqlStr2);
				stmt.executeUpdate(sqlStr2);
			} catch (SQLException e) {
				e.printStackTrace();
				return false;
			}
		return true;
	}

}
