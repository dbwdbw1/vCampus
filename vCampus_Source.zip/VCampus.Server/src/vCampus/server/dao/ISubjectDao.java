package vCampus.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Subject;
import vCampus.common.baseClass.User;
import vCampus.common.imp.ISubjectInterface;

public class ISubjectDao implements ISubjectInterface {
	
	private ObjectMapper mapper;
	
	public ISubjectDao() {
		mapper = new ObjectMapper();
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#list(vCampus.common.baseClass.User)
	 */
	@Override
	public Subject[] list(User user) {
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		try {
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
		String sqlStr2 = "select * from tblSubject";
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);//���û��Ƿ����
			if(!rs1.next())
			{
				return null;
			}
			ResultSet rs2 = stmt.executeQuery(sqlStr2);			
			int count =0;
			while(rs2.next())
			{
				count++;
			}
			Subject subject[]=new Subject[count];
			ResultSet rs21 = stmt.executeQuery(sqlStr2);	
			rs21.next();
			for(int i=0;i<count;i++)
			{
				subject[i] = new Subject();
				subject[i].setId(rs21.getString("ssid"));
				subject[i].setName(rs21.getString("ssname"));
				subject[i].setTeacher(rs21.getString("ssteacher"));
				subject[i].setTime(rs21.getString("sstime"));
				subject[i].setClassroom(rs21.getString("ssclassroom"));
				subject[i].setDetail(rs21.getString("ssdetail"));
				rs21.next();
			}
			return subject;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}
	

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#select(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean select(User user, String subjectId) {
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		String id = user.getId();
		String sqlStr0 = "select * from tblUser where uid='"+id+"'";
		ResultSet rs0;
		try {
			rs0 = stmt.executeQuery(sqlStr0);
			if(!rs0.next())
			{
				return false;
			}
			System.out.println("success");
		} catch (SQLException e2) {
			e2.printStackTrace();
			return false;
		}//��ѯ�Ƿ��д��û�
		
		String sqlStr1 = "select * from tblSubject where ssid='"+subjectId+"'";//��ѯ�Ƿ��д˿�
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);
			if(!rs1.next())
			{
				return false;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}//�޸�ͼ����Ϣ
		String sqlStr11 = "select usubjectInfo from tblUser where uid = '"+id+"'";
		String preStr = null;
		try {
			ResultSet rs11 = stmt.executeQuery(sqlStr11);
			rs11.next();
			preStr = rs11.getString("usubjectInfo");
			if(preStr==null)
			{
				preStr = "";
			}
		} catch (Exception e1) {
			e1.printStackTrace();
			return false;
		}
		List<String> subjectInfo = null;
		try {
			subjectInfo = mapper.readValue(preStr, List.class);
		} catch (Exception e1) {
			e1.printStackTrace();
			return false;
		}
		subjectInfo.add(subjectId);
		try {
			preStr = mapper.writeValueAsString(subjectInfo);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
			return false;
		}
			String sqlStr2 = "update tblUser set usubjectInfo = '"+preStr+"' where uid='"+id+"'";
		try {
			stmt.executeUpdate(sqlStr2);
			stmt.executeUpdate(sqlStr2);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#retreat(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean retreat(User user, String subjectId) {
		String id = user.getId();
		String sqlStr00 = "select usubjectInfo from tblUser where uid = '"+id+"'";
		String Str = null;
		
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		String sqlStr1 = "select * from tblSubject where ssid='"+subjectId+"'";//��ѯ�Ƿ��д˿�
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);
			if(!rs1.next())
			{
				return false;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			return false;
		}//�޸�ͼ����Ϣ
		try {
			ResultSet rs00 = stmt.executeQuery(sqlStr00);
			rs00.next();
			Str = rs00.getString("usubjectInfo");
			if (Str == null) {
				Str = "[]";
			}			
		} catch (SQLException e3) {
			e3.printStackTrace();
			return false;
		}
		
		List<String> subjectInfo = null;
		try {
			subjectInfo = mapper.readValue(Str, List.class);
		} catch (Exception e1) {
			e1.printStackTrace();
		} 
		for(int i = 0; i < subjectInfo.size(); i++){
			if (subjectInfo.get(i).equals(subjectId)) {
				subjectInfo.remove(i);
				break;
			}
		}
		try {
			Str = mapper.writeValueAsString(subjectInfo);
			System.out.println(Str);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}		
		String sqlStr0 = "select * from tblUser where uid='"+id+"'";
		ResultSet rs0;
		try {
			rs0 = stmt.executeQuery(sqlStr0);
			if(!rs0.next())
			{
				return false;
			}
		} catch (SQLException e2) {
			e2.printStackTrace();
			return false;
		}//��ѯ�Ƿ��д��û�
		
		
		String sqlStr2 = "update tblUser set usubjectInfo = '"+Str+"' where uid='"+id+"'";
		try {
			stmt.executeUpdate(sqlStr2);
			stmt.executeUpdate(sqlStr2);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#add(vCampus.common.baseClass.User, vCampus.common.baseClass.Subject)
	 */
	@Override
	public Boolean add(User user, Subject subject) {
		if(!user.getPower())
		{
			return false;
		}
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}//�������ݿ⣬����ָ����
		String sqlStr1 = "insert into tblSubject values('"+subject.getId()+"','"+subject.getName()+"','"+subject.getTeacher()+"','"+subject.getTime()+"','"+subject.getClassroom()+"','"+subject.getDetail()+"')";
		try {
			stmt.executeUpdate(sqlStr1);
			stmt.executeUpdate(sqlStr1);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#delete(vCampus.common.baseClass.User, java.lang.String)
	 */
	@Override
	public Boolean delete(User user, String subjectId) {
		if(!user.getPower())
		{
			return false;
		}
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}//�������ݿ�,ɾ��ָ����
		String sqlStr1 = "delete from tblSubject where ssid = '"+subjectId+"'";
		try {
			stmt.executeUpdate(sqlStr1);
			stmt.executeUpdate(sqlStr1);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
