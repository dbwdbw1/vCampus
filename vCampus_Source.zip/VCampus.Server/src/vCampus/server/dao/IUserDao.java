package vCampus.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.User;
import vCampus.common.imp.IUserInterface;

public class IUserDao implements IUserInterface {
	
	private ObjectMapper mapper;
	
	public IUserDao() {
		mapper = new ObjectMapper();
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IUserInterface#login(java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public User login(String id, String password) {
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
				System.out.println(path);
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sqlStr1 = "select * from tblUser where ustudentId='"+id+"'";
			ResultSet rs1 = null;
			try {
				rs1 = stmt.executeQuery(sqlStr1);
			} catch (SQLException e) {
				e.printStackTrace();
			}//���û��Ƿ����
			try {
				if(!rs1.next())
				{
					return null;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			try {
				ResultSet rs11 = stmt.executeQuery(sqlStr1);
				rs11.next();
				String uid = rs11.getString("ustudentId");
				String sqlStr2 = "select * from tblUser where ustudentId='"+uid+"'";
				ResultSet rs2 = stmt.executeQuery(sqlStr2);
				rs2.next();
				if(password.equals(rs2.getString("upwd")))
				{
					boolean flag = false;
					if(rs2.getInt("upower")!=0)
					{
						flag = true;
					}
					List<String> subjectInfo = null;
					List<String> bookInfo = null;
					@SuppressWarnings("rawtypes")
					List<List> commInfo = null;
					try {
						subjectInfo = mapper.readValue(rs2.getString("usubjectInfo"), List.class);
						bookInfo = mapper.readValue(rs2.getString("ubookinfo"), List.class);
						commInfo = mapper.readValue(rs2.getString("ucomminfo"), List.class);
					} catch (Exception e) {
						e.printStackTrace();
						return null;
					}
					User user = new User(uid,password,flag,rs2.getInt("ubalance"),rs2.getString("ustudentId"),rs2.getString("udomiId"), subjectInfo, bookInfo, commInfo);
					return user;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		return null;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IUserInterface#register(vCampus.common.baseClass.User)
	 */
	@Override
	public Boolean register(User user) {
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path; 
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}//�������ݿ⣬����ָ����
		int power = user.getPower()?1:0;
		try {
			mapper.writeValueAsString(user.getSubjectInfo());
			mapper.writeValueAsString(user.getBookInfo());
			mapper.writeValueAsString(user.getCommInfo());
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
			return false;
		}
		String sqlStr1 = "insert into tblUser values('"+user.getId()+"','"+user.getPassWord()+"',"+power+","+user.getBalance()+",'"+user.getStudentId()+"','"+user.getDomId()+"','"+user.getSubjectInfo()+"','"+user.getBookInfo()+"','"+user.getCommInfo()+"')";
		try {
			stmt.executeUpdate(sqlStr1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;//ע��ɹ�
	}

}
