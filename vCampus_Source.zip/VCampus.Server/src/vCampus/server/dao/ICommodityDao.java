package vCampus.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.common.baseClass.Commodity;
import vCampus.common.baseClass.User;
import vCampus.common.imp.ICommodityInterface;

public class ICommodityDao implements ICommodityInterface {
	
	private ObjectMapper mapper;
	
	public ICommodityDao() {
		mapper = new ObjectMapper();
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#list(vCampus.common.baseClass.User)
	 */
	@Override
	public Commodity[] list(User user) {
		
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {

			e.printStackTrace();
		}
		try {
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
		String sqlStr2 = "select * from tblcommodity ";
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);//���û��Ƿ����
			if(!rs1.next())
			{
				return null;
			}
			ResultSet rs2 = stmt.executeQuery(sqlStr2);			
			int count =0;
			while(rs2.next())
			{
				count++;
			}
			Commodity commodity[]=new Commodity[count];
			ResultSet rs21 = stmt.executeQuery(sqlStr2);	
			rs21.next();
			for(int i=0;i<count;i++)
			{
				commodity[i] = new Commodity();
				commodity[i].setId(rs21.getString("cid"));
				commodity[i].setName(rs21.getString("cname"));
				int cprice = Integer.parseInt(rs21.getString("cprice"));
				commodity[i].setPrice(cprice);
				commodity[i].setDetail(rs21.getString("cdetail"));
				int csales = Integer.parseInt(rs21.getString("csales"));
				commodity[i].setSales(csales);
				rs21.next();
			}
			return commodity;
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#purchase(vCampus.common.baseClass.User, java.lang.String, int)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean purchase(User user, String commodityId , int count) {
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}//�������ݿ⣬�޸��ƶ�����
		try {
			String sqlStr1 = "select cprice from tblcommodity where cid='"+commodityId+"'";
			ResultSet rs1 = stmt.executeQuery(sqlStr1);
			rs1.next();
			int price = Integer.parseInt(rs1.getString("cprice"));
			//�޸��û��������Ʒ��Ϣ
			String id=user.getId();
			String sqlStr11 = "select ucomminfo from tblUser where uid = '"+id+"'";
			ResultSet rs11 = stmt.executeQuery(sqlStr11);
			rs11.next();
			String preStr = rs11.getString("ucomminfo");
			if (preStr == null) {
				preStr = "[]";
			}
			@SuppressWarnings("rawtypes")
			List<List> commInfo = null;
			try {
				commInfo = mapper.readValue(preStr, List.class);
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			} 
			int i;
			for(i = 0; i < commInfo.size(); i++){
				if(commInfo.get(i).get(0).toString().equals(commodityId)){
					commInfo.get(i).set(1, Integer.parseInt(commInfo.get(i).get(1).toString()) + count);
					break;
				}
			}
			if (i == commInfo.size()) {
				@SuppressWarnings("rawtypes")
				List comm = new ArrayList();
				comm.add(commodityId);
				comm.add(count);
				commInfo.add(comm);
			}
			try {
				preStr = mapper.writeValueAsString(commInfo);
			} catch (JsonProcessingException e) {				
				e.printStackTrace();
				return false;
			}
			String sqlStr2 = "update tblUser set ucomminfo = '"+preStr+"' where uid='"+id+"'";
			stmt.executeUpdate(sqlStr2);
			//�۳����
			int newbalance = user.getBalance()-count*price;
			String sqlStr3 = "update tblUser set ubalance = '"+newbalance+"' where uid='"+id+"'";
			stmt.executeUpdate(sqlStr3);
			//�޸���Ʒ����
			String sqlStr4 = "select csales from tblcommodity where cid='"+commodityId+"'";
			ResultSet rs4 = stmt.executeQuery(sqlStr4);
			rs4.next();
			int sales = Integer.parseInt(rs4.getString("csales"));
			System.out.println(sales);
			int newsales=sales+count;
			System.out.println(newsales);
			String salesStr = String.valueOf(newsales);
			String sqlStr5 = "update tblcommodity set csales = '"+salesStr+"' where cid='"+commodityId+"'";
			stmt.executeUpdate(sqlStr5);
			stmt.executeUpdate(sqlStr5);
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#add(vCampus.common.baseClass.User, vCampus.common.baseClass.Commodity)
	 */
	@Override
	public Boolean add(User user, Commodity commodity) {
		if(!user.getPower())
		{
			return false;
		}
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path; 
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}//�������ݿ⣬����ָ����
		String sqlStr1 = "insert into tblcommodity values('"+commodity.getId()+"','"+commodity.getName()+"','"+commodity.getPrice()+"','"+commodity.getDetail()+"','"+commodity.getSales()+"')";
		try {
			System.out.println("success");
			stmt.executeUpdate(sqlStr1);
			stmt.executeUpdate(sqlStr1);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#delete(vCampus.common.baseClass.User, java.lang.String)
	 */
	@Override
	public Boolean delete(User user, String commodityId) {
		if(!user.getPower())
		{
			return false;
		}
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path; 
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}//�������ݿ�,ɾ��ָ����
		String sqlStr1 = "delete * from tblcommodity where cid = '"+commodityId+"'";
		try {
			stmt.executeUpdate(sqlStr1);
			stmt.executeUpdate(sqlStr1);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#charge(vCampus.common.baseClass.User, int)
	 */
	@Override
	public Boolean charge(User user, int amount) {
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return false;
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
				return false;
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return false;
		}//�������ݿ⣬�޸��ƶ�����
		String sqlStr1 = "select ubalance from tblUser where uid = '"+user.getId()+"'";
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);
			String newbalance = null;
			if(rs1.next())
			{
				newbalance = rs1.getString("ubalance") ;
			}
			int str = Integer.parseInt(newbalance);
			newbalance = String.valueOf(amount + str);
			String sqlStr2 = "update tblUser set ubalance = '"+newbalance+"' where uid='"+user.getId()+"'";
			stmt.executeUpdate(sqlStr2);
			stmt.executeUpdate(sqlStr2);
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

}
