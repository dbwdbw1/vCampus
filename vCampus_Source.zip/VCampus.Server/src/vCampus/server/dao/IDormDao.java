package vCampus.server.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import vCampus.common.baseClass.Dorm;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IDormInterface;

public class IDormDao implements IDormInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IDormInterface#list(vCampus.common.baseClass.User)
	 */
	@Override
	public Dorm[] list(User user) {
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
		String sqlStr2 = "select * from tblDorm ";
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);//���û��Ƿ����
			if(!rs1.next())
			{
				return null;
			}
			boolean flag = false;
			if(user.getPower())//�Ƿ����Ա
			{
				flag = true;
			}
			ResultSet rs2 = stmt.executeQuery(sqlStr2);			
			int count =0;
			while(rs2.next())
			{
				count++;
			}
			Dorm dorm[]=new Dorm[count];
			ResultSet rs21 = stmt.executeQuery(sqlStr2);	
			rs21.next();
			for(int i=0;i<count;i++)
			{
				dorm[i] = new Dorm();
				dorm[i].setId(rs21.getString("did"));
				dorm[i].setName(rs21.getString("dname"));
				dorm[i].setStudent1Name(rs21.getString("dstudent1Name"));
				dorm[i].setStudent2Name(rs21.getString("dstudent2Name"));
				dorm[i].setStudent3Name(rs21.getString("dstudent3Name"));
				dorm[i].setStudent4Name(rs21.getString("dstudent4Name"));
				dorm[i].setUtilities(rs21.getInt("dutilities"));
				dorm[i].setHotWater(rs21.getBoolean("dhotwater"));
				rs21.next();
			}
			if(flag)
			{
				return dorm;
			}
			else
			{
				id = user.getId();
				String sqlStr3 = "select udomiId from tblUser where uid='"+id+"'";
				ResultSet rs3 = stmt.executeQuery(sqlStr3);	
				rs3.next();
				String dormid = rs3.getString("udomiId");
				String sqlStr4 = "select * from tblDorm where dname='"+dormid+"'";
				ResultSet rs4 = stmt.executeQuery(sqlStr4);	
				rs4.next();
				Dorm dorm0[] = new Dorm[1];
				dorm0[0] = new  Dorm();
				dorm0[0].setId(rs4.getString("did"));
				dorm0[0].setName(rs4.getString("dname"));
				dorm0[0].setStudent1Name(rs4.getString("dstudent1Name"));
				dorm0[0].setStudent2Name(rs4.getString("dstudent2Name"));
				dorm0[0].setStudent3Name(rs4.getString("dstudent3Name"));
				dorm0[0].setStudent4Name(rs4.getString("dstudent4Name"));
				dorm0[0].setUtilities(rs4.getInt("dutilities"));
				dorm0[0].setHotWater(rs4.getBoolean("dhotwater"));
				return dorm0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

}
