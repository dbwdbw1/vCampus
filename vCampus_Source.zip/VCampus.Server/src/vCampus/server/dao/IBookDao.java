package vCampus.server.dao;

import vCampus.common.baseClass.Book;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IBookInterface;
import java.sql.*;
import java.util.List;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper; 

public class IBookDao implements IBookInterface {
	
	private ObjectMapper mapper;
	
	public IBookDao() {
		mapper = new ObjectMapper();
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IBookInterface#list(vCampus.common.baseClass.User)
	 */
	@Override
	public Book[] list(User user) {
		
		String id = user.getId();
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
				System.out.println(path);
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		String sqlStr1 = "select * from tblUser where uid='"+id+"'";
		String sqlStr2 = "select * from tblbook ";
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);//���û��Ƿ����
			if(!rs1.next())
			{
				return null;
			}
			
			ResultSet rs2 = stmt.executeQuery(sqlStr2);			
			int count =0;
			while(rs2.next())
			{
				count++;
			}
			if (count == 0) {
				return null;
			}
			Book book[]=new Book[count];
			ResultSet rs21 = stmt.executeQuery(sqlStr2);
			rs21.next();
			for(int i=0;i<count;i++)
			{
				book[i] = new Book();
				book[i].setId(rs21.getString("bid"));
				book[i].setName(rs21.getString("bname"));
				book[i].setAuthor(rs21.getString("bauthor"));
				book[i].setDetail(rs21.getString("bdetail"));
				rs21.next();
			}
			return book;
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IBookInterface#select(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean select(User user, String bookId) {
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			System.out.println("���ݿ��������س���");
			e.printStackTrace();
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				System.out.println("���ݿ���س���");
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			System.out.println("���ݿ���ʳ���");
			e.printStackTrace();
		}
		String id = user.getId();
		String sqlStr0 = "select * from tblUser where uid='"+id+"'";
		ResultSet rs0;
		try {
			rs0 = stmt.executeQuery(sqlStr0);
			if(!rs0.next())
			{
				System.out.println("�û�������");
				return false;
			}
		} catch (SQLException e2) {
			System.out.println("���ݿ���ʳ���");
			e2.printStackTrace();
		}//��ѯ�Ƿ��д��û�
		String sqlStr1 = "select * from tblbook where bid='"+bookId+"'";//��ѯ�Ƿ��д���
		try {
			ResultSet rs1 = stmt.executeQuery(sqlStr1);
			if(!rs1.next())
			{
				return false;
			}
		} catch (SQLException e1) {
			System.out.println("���ݿ���ʳ���");
			e1.printStackTrace();
			return null;
		}//�޸�ͼ����Ϣ
		String sqlStr3 = "select ubookinfo from tblUser where uid='"+id+"'";
		String preStr =null;
		List<String> bookInfo = null;
		try {
			ResultSet rs3 = stmt.executeQuery(sqlStr3);
			rs3.next();
			preStr = rs3.getString("ubookinfo");
			if (preStr == null) {
				preStr = "[]";
			}
		    bookInfo = mapper.readValue(preStr, List.class);
		} catch (Exception e1) {
			e1.printStackTrace();
			return null;
		}
		bookInfo.add(bookId);
		try {
			preStr = mapper.writeValueAsString(bookInfo);
		} catch (JsonProcessingException e1) {
			
			e1.printStackTrace();
		}
		String sqlStr2 = "update tblUser set ubookinfo = '"+preStr+"' where uid='"+id+"'";
		try {
			stmt.executeUpdate(sqlStr2);
			stmt.executeUpdate(sqlStr2);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IBookInterface#retreat(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean retreat(User user, String bookId) {
		String id = user.getId();
		String sqlStr3 = "select ubookinfo from tblUser where uid='"+id+"'";
		String preStr =null;
		Connection odbcConn=null;
		Statement stmt=null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try
		{
			String path = null;
			try {
				path = System.getProperty("user.dir") + "/res/vCampus.accdb";
			} catch (Exception e) {
				e.printStackTrace();
			}
			String url="jdbc:odbc:driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=" + path;     //Access ����
			odbcConn = DriverManager.getConnection(url);
			stmt = odbcConn.createStatement();
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		try {
			ResultSet rs3 = stmt.executeQuery(sqlStr3);
			rs3.next();
			preStr = rs3.getString("ubookinfo");
			if (preStr == null) {
				preStr = "[]";
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
			return null;
		}
		
		List<String> bookInfo = null;
		try {
			bookInfo = mapper.readValue(preStr, List.class);
		} catch (Exception e3) {
			e3.printStackTrace();
		} 
		for(int i = 0; i < bookInfo.size(); i++){
			if (bookInfo.get(i).equals(bookId)) {
				bookInfo.remove(i);
			}
		}
		try {
			preStr = mapper.writeValueAsString(bookInfo);
		} catch (JsonProcessingException e3) {
			e3.printStackTrace();
		}
		
		String sqlStr2 = "update tblUser set ubookinfo = '"+preStr+"' where uid='"+id+"'";
		try {
			stmt.executeUpdate(sqlStr2);
			stmt.executeUpdate(sqlStr2);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return true;
	}
}


