package vCampus.common.baseClass;

import java.lang.String;
import java.util.List;
import java.io.Serializable;

public class User implements Serializable{
	
	public User(){
		
	}
	
	public User(String Id, String Password, boolean Power, int Balance, String StudentId, String DomId, List<String> SubjectInfo, List<String> BookInfo, @SuppressWarnings("rawtypes") List<List> CommInfo){
		
		this.id = Id;
		this.password = Password;
		this.power = Power;
		this.balance = Balance;
		this.studentId = StudentId;
		this.domId = DomId;
		this.subjectInfo = SubjectInfo;
		this.bookInfo = BookInfo;		
		this.commInfo = CommInfo;
		
	}
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * �û�id�����ݿ��еı�ʶ�ֶ�
	 */
	private String id;
	
	/**
	 * �û�����
	 */
	private String password;
	
	/**
	 * �û�Ȩ�ޣ�ΪtrueʱΪ����Ա
	 */
	private boolean power;
	
	/**
	 * �û��˻����
	 */
	private int balance;
	
	/**
	 * �û���ѧ���ţ�Ϊ��¼�˻�
	 */
	private String studentId;
	
	/**
	 * �û����������ƺ�
	 */
	private String domId;
	
	/**
	 * �û��Ŀγ���Ϣ
	 */
	private List<String> subjectInfo;
	
	/**
	 * �û��Ľ�����Ϣ
	 */
	private List<String> bookInfo;
	
	/**
	 * �û��Ĺ�����Ϣ
	 */
	@SuppressWarnings("rawtypes")
	private List<List> commInfo;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassWord() {
		return password;
	}

	public void setPassWord(String passWord) {
		this.password = passWord;
	}

	public boolean getPower() {
		return power;
	}

	public void setPower(boolean power) {
		this.power = power;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getDomId() {
		return domId;
	}

	public void setDomId(String domId) {
		this.domId = domId;
	}

	public List<String> getSubjectInfo() {
		return subjectInfo;
	}

	public void setSubjectInfo(List<String> subjectInfo) {
		this.subjectInfo = subjectInfo;
	}

	public List<String> getBookInfo() {
		return bookInfo;
	}

	public void setBookInfo(List<String> bookInfo) {
		this.bookInfo = bookInfo;
	}

	@SuppressWarnings("rawtypes")
	public List<List> getCommInfo() {
		return commInfo;
	}

	@SuppressWarnings("rawtypes")
	public void setCommInfo(List<List> commInfo) {
		this.commInfo = commInfo;
	}
}
