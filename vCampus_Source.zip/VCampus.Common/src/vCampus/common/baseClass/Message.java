package vCampus.common.baseClass;

import java.io.Serializable;
import java.util.HashMap;

public class Message implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * ��Ϣ����ģ��
	 */
	private String domain;
	
	/**
	 * ��Ϣ��������
	 */
	private String name;
	
	@SuppressWarnings("rawtypes")
	private HashMap data;
	
	public Message(){
		
	}
	
	public Message(String Domain, String Name, @SuppressWarnings("rawtypes") HashMap Data){
		this.domain = Domain;
		this.name = Name;
		this.data = Data;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@SuppressWarnings("rawtypes")
	public HashMap getData() {
		return data;
	}

	@SuppressWarnings("rawtypes")
	public void setData(HashMap data) {
		this.data = data;
	}

}
