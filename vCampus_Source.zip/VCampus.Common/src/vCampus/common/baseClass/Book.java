package vCampus.common.baseClass;

import java.lang.String;

import java.io.Serializable;

public class Book implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ��id�����ݿ�ı�ʶ��Ϣ
	 */
	private String id;
	
	/**
	 * ����
	 */
	private String name;
	
	/**
	 * ����
	 */
	private String author;
	
	/**
	 * ���
	 */
	private String detail;
	
	public Book() {
		
	}
	
	public Book(String Id, String Name, String Author, String Detail) {
		
		this.id = Id;
		this.name = Name;
		this.author = Author;
		this.detail = Detail;
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}

}
