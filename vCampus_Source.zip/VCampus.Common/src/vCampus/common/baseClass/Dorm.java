package vCampus.common.baseClass;

import java.io.Serializable;

import java.lang.String;
import java.lang.Boolean;

public class Dorm implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	/**
	 * ����id�����ݿ��еı�ʶ�ֶ�
	 */
	private String id;
	
	/**
	 * ������
	 */
	private String name;
	
	/**
	 * ѧ��1������
	 */
	private String student1Name;
	
	/**
	 * ѧ��2������
	 */
	private String student2Name;
		
	/**
	 * ѧ��3������
	 */
	private String student3Name;
		
	/**
	 * ѧ��1������
	 */
	private String student4Name;
	
	/**
	 * Ӧ��ˮ���
	 */
	private int utilities;
	
	/**
	 * ������ˮ��Ӧ���
	 */
	private Boolean hotWater;
	
	public Dorm() {
		
	}

	public Dorm(String Id, String Name, String Student1Name, String Student2Name, String Student3Name, String Student4Name, int Utilities, Boolean HotWater){
		
		this.id = Id;
		this.name = Name;
		this.student1Name = Student1Name;
		this.student2Name = Student2Name;
		this.student3Name = Student3Name;
		this.student4Name = Student4Name;
		this.utilities = Utilities;
		this.hotWater = HotWater;
		
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStudent1Name() {
		return student1Name;
	}

	public void setStudent1Name(String student1Name) {
		this.student1Name = student1Name;
	}

	public String getStudent2Name() {
		return student2Name;
	}

	public void setStudent2Name(String student2Name) {
		this.student2Name = student2Name;
	}

	public String getStudent3Name() {
		return student3Name;
	}

	public void setStudent3Name(String student3Name) {
		this.student3Name = student3Name;
	}

	public String getStudent4Name() {
		return student4Name;
	}

	public void setStudent4Name(String student4Name) {
		this.student4Name = student4Name;
	}

	public int getUtilities() {
		return utilities;
	}

	public void setUtilities(int utilities) {
		this.utilities = utilities;
	}

	public Boolean getHotWater() {
		return hotWater;
	}

	public void setHotWater(Boolean hotWater) {
		this.hotWater = hotWater;
	}

}
