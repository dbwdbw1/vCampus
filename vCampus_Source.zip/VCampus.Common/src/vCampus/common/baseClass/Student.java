package vCampus.common.baseClass;

import java.lang.String;

import java.io.Serializable;

public class Student implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ѧ��id�����ݿ��еı�ʶ�ֶ�
	 */
	private String id;
	
	/**
	 * ѧ������
	 */
	private String name;
	
	/**
	 * ѧ������ѧԺ
	 */
	private String college;
	

	/**
	 * ѧ������רҵ
	 */
	private String major;
	
	/**
	 * ѧ�������꼶
	 */
	private int grade;
	
	/**
	 * ѧ���Ա�
	 */
	private String gender;
	
	/**
	 * ѧ���绰
	 */
	private String phone;
	
	public Student() {
		
	}
	
	public Student(String Id, String Name, String College, String Major, int Grade, String Gender, String Phone){
		
		this.id = Id;
		this.name = Name;
		this.college = College;
		this.major = Major;
		this.grade = Grade;
		this.gender = Gender;
		this.phone = Phone;
		
	}
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCollege() {
		return college;
	}

	public void setCollege(String college) {
		this.college = college;
	}

	public String getMajor() {
		return major;
	}

	public void setMajor(String major) {
		this.major = major;
	}

	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}
}
