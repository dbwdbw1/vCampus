package vCampus.common.baseClass;

import java.io.Serializable;

import java.lang.String;

public class Subject implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * �γ�id�����ݿ��еı�ʶ�ֶ�
	 */
	private String id;
	
	/**
	 * �γ�����
	 */
	private String name;
	
	/**
	 * �ο���ʦ
	 */
	private String teacher;
	
	/**
	 * �γ�ʱ��
	 */
	private String time;
	
	/**
	 * �γ����ڽ���
	 */
	private String classroom;
	
	/**
	 * �γ̼��
	 */
	private String detail;
	
	public Subject(){
		
	}
	
	public Subject(String Id, String Name, String Teacher, String Time, String Classroom, String Detail){
		
		this.id = Id;
		this.name = Name;
		this.teacher = Teacher;
		this.time = Time;
		this.classroom = Classroom;
		this.detail = Detail;
		
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTeacher() {
		return teacher;
	}

	public void setTeacher(String teacher) {
		this.teacher = teacher;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getClassroom() {
		return classroom;
	}

	public void setClassroom(String classroom) {
		this.classroom = classroom;
	}

	public String getDetail() {
		return detail;
	}

	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	
}
