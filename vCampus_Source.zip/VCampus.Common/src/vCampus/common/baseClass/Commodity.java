package vCampus.common.baseClass;

import java.lang.String;

import java.io.Serializable;

public class Commodity implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * ��Ʒid�����ݿ��ʶ
	 */
	private String id;
	

	/**
	 * ��Ʒ����
	 */
	private String name;
	

	/**
	 * ��Ʒ�۸�
	 */
	private int price;
	

	/**
	 * ��Ʒ��ϸ��Ϣ
	 */
	private String detail;
	
	/**
	 * ��Ʒ����
	 */
	private int sales;
	
	
	public Commodity() {
		
	}

	public Commodity(String Id, String Name, int Price, String Detail, int Sales) {
		
		this.id = Id;
		this.name = Name;
		this.price = Price;
		this.detail = Detail;
		this.sales = Sales;
		
	}

	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public String getDetail() {
		return detail;
	}


	public void setDetail(String detail) {
		this.detail = detail;
	}


	public int getSales() {
		return sales;
	}


	public void setSales(int sales) {
		this.sales = sales;
	}

}
