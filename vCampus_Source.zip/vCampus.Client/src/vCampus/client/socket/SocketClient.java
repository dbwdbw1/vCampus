package vCampus.client.socket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.net.Socket;
import java.net.SocketTimeoutException;

public class SocketClient {
	public static SocketClient socketClient = new SocketClient();
	
	private String host;
	private int port;

	public SocketClient() {
		host = "127.0.0.1";
		port = 2333;
	}

	public String connect(String data) throws IOException {
		Socket client = new Socket(host, port);
		// �������Ӻ�Ϳ����������д������
		Writer writer = new OutputStreamWriter(client.getOutputStream(), "UNICODE");
		//writer.write("��ã�����ˡ�\n");
		writer.write(data);
		writer.write("eof\n");
		writer.flush();
		// д���Ժ���ж�����
		BufferedReader br = new BufferedReader(new InputStreamReader(client.getInputStream(), "UNICODE"));
		// ���ó�ʱ��Ϊ10��
		client.setSoTimeout(10 * 1000);
		StringBuffer sb = new StringBuffer();
		String temp;
		int index;
		try {
			while ((temp = br.readLine()) != null) {
				if ((index = temp.indexOf("eof")) != -1) {
					sb.append(temp.substring(0, index));
					break;
				}
				sb.append(temp);
			}
		} catch (SocketTimeoutException e) {
			System.out.println("���ݶ�ȡ��ʱ��");
			return null;
		}
		writer.close();
		br.close();
		client.close();
		
		return sb.toString();
	}
	
	/*public static void main(String[] args) {
		boolean test;
		IUserDao iUserDao = new IUserDao();
		User user = iUserDao.login("0", "123456");
		
		IBookDao iBookDao = new IBookDao();
		
		test = iBookDao.retreat(user, "1");

		ICommodityDao iCommodityDao = new ICommodityDao();

		System.out.println(test);
	}*/

}
