package vCampus.client.dao;

import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.client.socket.SocketClient;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.Subject;
import vCampus.common.baseClass.User;
import vCampus.common.imp.ISubjectInterface;

public class ISubjectDao implements ISubjectInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#list(vCampus.common.baseClass.User)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Subject[] list(User user) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
        Message message = new Message("Subject", "list", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        Subject[] subjects = null;
        try {
			subjects = mapper.readValue(result, Subject[].class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return subjects;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#select(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean select(User user, String subjectId) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("subjectId", subjectId);
        Message message = new Message("Subject", "select", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#retreat(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean retreat(User user, String subjectId) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("subjectId", subjectId);
        Message message = new Message("Subject", "retreat", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#add(vCampus.common.baseClass.User, vCampus.common.baseClass.Subject)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean add(User user, Subject subject) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("subject", subject);
        Message message = new Message("Subject", "add", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ISubjectInterface#delete(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean delete(User user, String subjectId) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("subjectId", subjectId);
        Message message = new Message("Subject", "delete", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

}
