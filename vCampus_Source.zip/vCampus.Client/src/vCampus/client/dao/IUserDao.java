package vCampus.client.dao;

import java.io.IOException;
import java.util.HashMap;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import vCampus.client.socket.SocketClient;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IUserInterface;

public class IUserDao implements IUserInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IUserInterface#login(java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public User login(String id, String password) {
		
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("id", id);
		map.put("password", password);
		Message message = new Message("User", "login", map);
				
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}

		System.out.println(json);
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        
        User user = null;
		try {
			user = mapper.readValue(result, User.class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return user;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IUserInterface#register(vCampus.common.baseClass.User)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean register(User user) {
		
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		
		Message message = new Message("User", "register", map);
		
		ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		String result = null;
		try {
			result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return Boolean.parseBoolean(result);
	}

}
