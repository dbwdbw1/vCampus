package vCampus.client.dao;

import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.client.socket.SocketClient;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.Student;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IStudentInterface;

public class IStudentDao implements IStudentInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#list(vCampus.common.baseClass.User)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Student[] list(User user) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
        Message message = new Message("Student", "list", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        Student[] students = null;
        try {
			students = mapper.readValue(result, Student[].class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return students;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#add(vCampus.common.baseClass.User, vCampus.common.baseClass.Student)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean add(User user, Student student) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("student", student);
        Message message = new Message("Student", "add", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#delete(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean delete(User user, String id) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("studentId", id);
        Message message = new Message("Student", "delete", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IStudentInterface#update(vCampus.common.baseClass.User, vCampus.common.baseClass.Student)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean update(User user, Student student) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("student", student);
        Message message = new Message("Student", "update", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

}
