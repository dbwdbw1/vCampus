package vCampus.client.dao;

import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.client.socket.SocketClient;
import vCampus.common.baseClass.Dorm;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IDormInterface;

public class IDormDao implements IDormInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IDormInterface#list(vCampus.common.baseClass.User)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Dorm[] list(User user) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
        Message message = new Message("Dorm", "list", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        Dorm[] dorms = null;
        try {
			dorms = mapper.readValue(result, Dorm[].class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return dorms;
	}

}
