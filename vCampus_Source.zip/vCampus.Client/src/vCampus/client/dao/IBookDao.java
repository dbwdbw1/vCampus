package vCampus.client.dao;

import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.client.socket.SocketClient;
import vCampus.common.baseClass.Book;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;
import vCampus.common.imp.IBookInterface;

/**
 * @author qazxd
 *
 */
public class IBookDao implements IBookInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IBookInterface#list(vCampus.common.baseClass.User)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Book[] list(User user) {
		
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
        Message message = new Message("Book", "list", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        Book[] books = null;
        try {
			books = mapper.readValue(result, Book[].class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return books;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IBookInterface#select(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean select(User user, String bookId) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("bookId", bookId);
        Message message = new Message("Book", "select", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.IBookInterface#retreat(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean retreat(User user, String bookId) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("bookId", bookId);
        Message message = new Message("Book", "retreat", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

}
