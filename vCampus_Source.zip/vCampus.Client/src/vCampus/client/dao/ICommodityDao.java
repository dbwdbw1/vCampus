package vCampus.client.dao;

import java.io.IOException;
import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import vCampus.client.socket.SocketClient;
import vCampus.common.baseClass.Commodity;
import vCampus.common.baseClass.Message;
import vCampus.common.baseClass.User;

/**
 * @author qazxd
 *
 */
public class ICommodityDao implements vCampus.common.imp.ICommodityInterface {

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#list(vCampus.common.baseClass.User)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Commodity[] list(User user) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
        Message message = new Message("Commodity", "list", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        Commodity[] commodities = null;
        try {
			commodities = mapper.readValue(result, Commodity[].class);
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
		return commodities;
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#purchase(vCampus.common.baseClass.User, java.lang.String, int)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean purchase(User user, String commodityId, int count) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("commodityId", commodityId);
		map.put("count", count);
        Message message = new Message("Commodity", "purchase", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#charge(vCampus.common.baseClass.User, int)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean charge(User user, int amount) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("amount", amount);
        Message message = new Message("Commodity", "charge", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#add(vCampus.common.baseClass.User, vCampus.common.baseClass.Commodity)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean add(User user, Commodity commodity) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("commodity", commodity);
        Message message = new Message("Commodity", "add", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

	/* (non-Javadoc)
	 * @see vCampus.common.imp.ICommodityInterface#delete(vCampus.common.baseClass.User, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Boolean delete(User user, String commodityId) {
		@SuppressWarnings("rawtypes")
		HashMap map = new HashMap();
		map.put("user", user);
		map.put("commodityId", commodityId);
        Message message = new Message("Commodity", "delete", map);
        
        ObjectMapper mapper = new ObjectMapper();
		String json = null;
		try {
			json = mapper.writeValueAsString(message);
		} catch (JsonProcessingException e1) {
			e1.printStackTrace();
		}
        String result;       
        try {
		    result = SocketClient.socketClient.connect(json);
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
        return Boolean.parseBoolean(result);
	}

}
