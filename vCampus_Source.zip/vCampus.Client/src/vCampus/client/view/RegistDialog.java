package vCampus.client.view;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;
import org.jdesktop.swingx.JXImagePanel;

import vCampus.client.control.RegistAction;

public class RegistDialog extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public LoginDialog loginDialog;
	
	public RegistDialog(LoginDialog loginDialog) {
		super(loginDialog, "ע��", true);
		
		this.loginDialog = loginDialog;
		
		setBounds(330, 260, 300, 403);
		
		JXImagePanel jxImagePanel = null;
		try {
			jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/Personal_Background.png"));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		jxImagePanel.setBounds(0, 0, 300, 104);
		
		JLabel idLabel = new JLabel("�˺�");
		idLabel.setFont(new Font("΢���ź�", 0, 14));
		idLabel.setBounds(20, 115, 80, 28);
		
		JTextField idTextField = new JTextField();
		idTextField.setFont(new Font("΢���ź�", 0, 12));
		idTextField.setBounds(100, 115, 160, 28);
		
		
		JLabel passwordLabel = new JLabel("����");
		passwordLabel.setFont(new Font("΢���ź�", 0, 14));
		passwordLabel.setBounds(20, 160, 80, 28);		
		
		JPasswordField passwordTextField = new JPasswordField();
		passwordTextField.setFont(new Font("΢���ź�", 0, 14));
		passwordTextField.setBounds(100, 160, 160, 28);
		
		JLabel repasswordLabel = new JLabel("ȷ������");
		repasswordLabel.setFont(new Font("΢���ź�", 0, 14));
		repasswordLabel.setBounds(20, 205, 80, 28);		
		
		JPasswordField repasswordTextField = new JPasswordField();
		repasswordTextField.setFont(new Font("΢���ź�", 0, 14));
		repasswordTextField.setBounds(100, 205, 160, 28);
		
		JLabel domIdLabel = new JLabel("����");
		domIdLabel.setFont(new Font("΢���ź�", 0, 14));
		domIdLabel.setBounds(20, 250, 80, 28);
		
		JTextField domIdField = new JTextField();
		domIdField.setFont(new Font("΢���ź�", 0, 14));
		domIdField.setBounds(100, 250, 160, 28);
		
		JButton registButton = new JButton("ע��");
	    registButton.setForeground(Color.WHITE);
	    registButton.setFont(new Font("΢���ź�", 0, 12));
		registButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		registButton.setBounds(50, 295, 70, 30);
		registButton.addActionListener(new RegistAction(idTextField, passwordTextField, repasswordTextField, domIdField, this));
		
		JButton cancleButton = new JButton("ȡ��");
		cancleButton.setForeground(Color.WHITE);
		cancleButton.setFont(new Font("΢���ź�", 0, 12));
		cancleButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		cancleButton.setBounds(170, 295, 70, 30);
		cancleButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		
				
		Container container = getContentPane();
		container.setLayout(null);
		
		container.add(jxImagePanel);
		container.add(idLabel);
		container.add(idTextField);
		container.add(repasswordLabel);
		container.add(repasswordTextField);
		container.add(passwordLabel);
		container.add(passwordTextField);
		container.add(registButton);
		container.add(cancleButton);
		container.add(domIdLabel);
		container.add(domIdField);
	}

}
