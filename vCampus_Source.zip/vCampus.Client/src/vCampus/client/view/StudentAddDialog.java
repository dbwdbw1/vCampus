package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.StudentAddAction;

public class StudentAddDialog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public StudentPanel studentPanel;
	
	public StudentAddDialog(StudentPanel studentPanel) {
		super(studentPanel.mainFram, "����ѧ����Ϣ", true);
		this.studentPanel = studentPanel;
		setLayout(null);
		
		setBounds(330, 260, 300, 420);
		
		JLabel idLabel = new JLabel("ѧ��");
		idLabel.setFont(new Font("΢���ź�", 0, 14));
		idLabel.setBounds(20, 15, 80, 28);
		
		JTextField idTextField = new JTextField();
		idTextField.setFont(new Font("΢���ź�", 0, 12));
		idTextField.setBounds(100, 15, 160, 28);
				
		JLabel nameLabel = new JLabel("����");
		nameLabel.setFont(new Font("΢���ź�", 0, 14));
		nameLabel.setBounds(20, 60, 80, 28);
		
		JTextField nameTextField = new JTextField();
		nameTextField.setFont(new Font("΢���ź�", 0, 12));
		nameTextField.setBounds(100, 60, 160, 28);
		
		JLabel collegeLabel = new JLabel("ѧԺ��ϵ��");
		collegeLabel.setFont(new Font("΢���ź�", 0, 14));
		collegeLabel.setBounds(20, 105, 80, 28);
		
		JTextField collegeTextField = new JTextField();
		collegeTextField.setFont(new Font("΢���ź�", 0, 12));
		collegeTextField.setBounds(100, 105, 160, 28);
		
		JLabel majorLabel = new JLabel("רҵ");
		majorLabel.setFont(new Font("΢���ź�", 0, 14));
		majorLabel.setBounds(20, 150, 80, 28);
		
		JTextField majorTextField = new JTextField();
		majorTextField.setFont(new Font("΢���ź�", 0, 12));
		majorTextField.setBounds(100, 150, 160, 28);
		
		JLabel gradeLabel = new JLabel("�꼶");
		gradeLabel.setFont(new Font("΢���ź�", 0, 14));
		gradeLabel.setBounds(20, 195, 80, 28);
		
		SpinnerModel model = new SpinnerNumberModel(1, 1, 5, 1);
		JSpinner gradeSpinner = new JSpinner(model);
		gradeSpinner.setBounds(100, 195, 80, 28);		
		
		JLabel genderLabel = new JLabel("�Ա�");
		genderLabel.setFont(new Font("΢���ź�", 0, 14));
		genderLabel.setBounds(20, 240, 80, 28);
		
		JRadioButton manButton = new JRadioButton("��");
		manButton.setBounds(100, 240, 80, 28);
		JRadioButton womanButton = new JRadioButton("Ů");
		womanButton.setBounds(200, 240, 80, 28);
		ButtonGroup genderGroup = new ButtonGroup();
		genderGroup.add(manButton);
		genderGroup.add(womanButton);		
		
		JLabel telLabel = new JLabel("�绰");
		telLabel.setFont(new Font("΢���ź�", 0, 14));
		telLabel.setBounds(20, 285, 80, 28);
		
		JTextField telTextField = new JTextField();
		telTextField.setFont(new Font("΢���ź�", 0, 12));
		telTextField.setBounds(100, 285, 160, 28);
		telTextField.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				int keyChar = e.getKeyChar();				
				if(keyChar >= KeyEvent.VK_0 && keyChar <= KeyEvent.VK_9){
					
				}else{
					e.consume(); //�ؼ������ε��Ƿ�����
				}
			}
		});
		
		JButton addButton = new JButton("ȷ��");
		addButton.setForeground(Color.WHITE);
		addButton.setFont(new Font("΢���ź�", 0, 12));
		addButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		addButton.setBounds(50, 330, 70, 30);		
		addButton.addActionListener(new StudentAddAction(this, idTextField, nameTextField, collegeTextField, majorTextField, gradeSpinner, manButton, womanButton, genderGroup, telTextField));
		
		JButton cancleButton = new JButton("ȡ��");
		cancleButton.setForeground(Color.WHITE);
		cancleButton.setFont(new Font("΢���ź�", 0, 12));
		cancleButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		cancleButton.setBounds(170, 330, 70, 30);
		cancleButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();				
			}
		});
		
		add(idLabel);
		add(idTextField);
		add(nameLabel);
		add(nameTextField);
		add(collegeLabel);
		add(collegeTextField);
		add(majorLabel);
		add(majorTextField);
		add(gradeLabel);
		add(gradeSpinner);
		add(genderLabel);
		add(manButton);
		add(womanButton);
		add(telLabel);
		add(telTextField);
		add(addButton);
		add(cancleButton);
	}
}
