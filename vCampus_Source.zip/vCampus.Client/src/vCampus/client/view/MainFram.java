package vCampus.client.view;

import java.awt.Color;
import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.UIManager;

import org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper;

import vCampus.common.baseClass.User;

public class MainFram extends JFrame {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public User user;
	
	private LoginDialog loginDialog;
	public UserPanel userPanel;
	private ModulePanel modulePanel;
	
	public MainFram() {
		Container container = this.getContentPane();
		container.setBackground(Color.WHITE);
		setLayout(null);
		this.setSize(960, 720);
		
		loginDialog = new LoginDialog(this);
		loginDialog.setVisible(true);
	}
	
	public void creatComponent(){
		userPanel = new UserPanel(this);
		userPanel.setBounds(10, 10, 250, 660);
		userPanel.creatUserInfo();
		
		modulePanel = new ModulePanel(this);
		modulePanel.setBounds(270, 10, 670, 660);
		modulePanel.creatTabbedPanel();
		
		add(userPanel);
		add(modulePanel);
	}
	
	

	public static void main(String[] args) {
		
		try{	        
	        BeautyEyeLNFHelper.frameBorderStyle = BeautyEyeLNFHelper.FrameBorderStyle.generalNoTranslucencyShadow;
	        org.jb2011.lnf.beautyeye.BeautyEyeLNFHelper.launchBeautyEyeLNF();
	        UIManager.put("RootPane.setupButtonVisible", false);
	    }
	    catch(Exception e){
	        e.printStackTrace();
	    }
		
		MainFram mainFram = new MainFram();
		mainFram.setResizable(false);

	}

}
