package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.SubjectAddAction;

public class SubjectAddDialog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public SubjectPanel subjectPanel;
	
	public SubjectAddDialog(SubjectPanel subjectPanel) {
		super(subjectPanel.mainFram, "���ӿγ���Ϣ", true);
		this.subjectPanel = subjectPanel;
		setLayout(null);
		
		setBounds(330, 260, 300, 370);
		
		JLabel idLabel = new JLabel("�γ̴���");
		idLabel.setFont(new Font("΢���ź�", 0, 14));
		idLabel.setBounds(20, 15, 80, 28);
		
		JTextField idTextField = new JTextField();
		idTextField.setFont(new Font("΢���ź�", 0, 12));
		idTextField.setBounds(100, 15, 160, 28);
				
		JLabel nameLabel = new JLabel("����");
		nameLabel.setFont(new Font("΢���ź�", 0, 14));
		nameLabel.setBounds(20, 60, 80, 28);
		
		JTextField nameTextField = new JTextField();
		nameTextField.setFont(new Font("΢���ź�", 0, 12));
		nameTextField.setBounds(100, 60, 160, 28);
		
		JLabel teacherLabel = new JLabel("�ο���ʦ");
		teacherLabel.setFont(new Font("΢���ź�", 0, 14));
		teacherLabel.setBounds(20, 105, 80, 28);
		
		JTextField teacherTextField = new JTextField();
		teacherTextField.setFont(new Font("΢���ź�", 0, 12));
		teacherTextField.setBounds(100, 105, 160, 28);
		
		JLabel timeLabel = new JLabel("�Ͽ�ʱ��");
		timeLabel.setFont(new Font("΢���ź�", 0, 14));
		timeLabel.setBounds(20, 150, 80, 28);
		
		JTextField timeTextField = new JTextField();
		timeTextField.setFont(new Font("΢���ź�", 0, 12));
		timeTextField.setBounds(100, 150, 160, 28);
		
		JLabel classLabel = new JLabel("����");
		classLabel.setFont(new Font("΢���ź�", 0, 14));
		classLabel.setBounds(20, 195, 80, 28);
		
		JTextField classTextField = new JTextField();
		classTextField.setFont(new Font("΢���ź�", 0, 12));
		classTextField.setBounds(100, 195, 160, 28);
		
		JLabel detailLabel = new JLabel("���");
		detailLabel.setFont(new Font("΢���ź�", 0, 14));
		detailLabel.setBounds(20, 240, 80, 28);
		
		JTextField detailTextField = new JTextField();
		detailTextField.setFont(new Font("΢���ź�", 0, 12));
		detailTextField.setBounds(100, 240, 160, 28);
		
		JButton addButton = new JButton("ȷ��");
		addButton.setForeground(Color.WHITE);
		addButton.setFont(new Font("΢���ź�", 0, 12));
		addButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		addButton.setBounds(50, 285, 70, 30);		
		addButton.addActionListener(new SubjectAddAction(this, idTextField, nameTextField, teacherTextField, timeTextField, classTextField, detailTextField));
		
		JButton cancleButton = new JButton("ȡ��");
		cancleButton.setForeground(Color.WHITE);
		cancleButton.setFont(new Font("΢���ź�", 0, 12));
		cancleButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		cancleButton.setBounds(170, 285, 70, 30);
		cancleButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				dispose();				
			}
		});
		
		add(idLabel);
		add(idTextField);
		add(nameLabel);
		add(nameTextField);
		add(teacherLabel);
		add(teacherTextField);
		add(timeLabel);
		add(timeTextField);
		add(classLabel);
		add(classTextField);
		add(detailLabel);
		add(detailTextField);
		add(addButton);
		add(cancleButton);
	}
}
