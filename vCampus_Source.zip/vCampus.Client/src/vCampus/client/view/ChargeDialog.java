package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.ChargeAction;

public class ChargeDialog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public UserPanel userPanel;
	
	public ChargeDialog(UserPanel userPanel) {
		super(userPanel.mainFram, "��ֵ", true);
		this.userPanel = userPanel;
		setLayout(null);
		
		setBounds(330, 260, 300, 160);
		
		JLabel hint = new JLabel("�������ֵ���");
		hint.setFont(new Font("΢���ź�", 0, 12));
		hint.setBounds(100, 15, 100, 20);
		
		JTextField textField = new JTextField();
		textField.setFont(new Font("΢���ź�", 0, 14));
		textField.setBounds(50, 45, 190, 25);
		textField.addKeyListener(new KeyAdapter() {
			public void keyTyped(KeyEvent e) {
				int keyChar = e.getKeyChar();				
				if(keyChar >= KeyEvent.VK_0 && keyChar <= KeyEvent.VK_9){
					
				}else{
					e.consume(); //�ؼ������ε��Ƿ�����
				}
			}

		});
		
		JButton chargeButton = new JButton("��ֵ");
	    chargeButton.setForeground(Color.WHITE);
	    chargeButton.setFont(new Font("΢���ź�", 0, 12));
	    chargeButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
	    chargeButton.setBounds(110, 80, 70, 30);
	    chargeButton.addActionListener(new ChargeAction(userPanel.user, textField, this));
		
		add(hint);
		add(textField);
		add(chargeButton);
	}
}
