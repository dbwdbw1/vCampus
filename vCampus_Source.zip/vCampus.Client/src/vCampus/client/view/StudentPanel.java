package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.StudentAddBAction;
import vCampus.client.control.StudentDeleteAction;
import vCampus.client.control.StudentListListenr;
import vCampus.client.control.StudentUpdateBAction;
import vCampus.client.dao.IStudentDao;
import vCampus.common.baseClass.Student;

public class StudentPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MainFram mainFram;
	
	public JButton addButton;
	public JButton deleteButton;
	public JButton updateButton;
	
	public JTable studentTable;
	public JScrollPane scrollPane;

	public StudentPanel(MainFram mainFram) {
		super();
		this.mainFram = mainFram;
		setLayout(null);
		
		addButton = new JButton("����");
		addButton.setForeground(Color.WHITE);
	    addButton.setFont(new Font("΢���ź�", 0, 12));
		addButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		addButton.setBounds(20, 10, 70, 30);
		addButton.setEnabled(false);
		addButton.addActionListener(new StudentAddBAction(this));
		
		deleteButton = new JButton("�Ƴ�");
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setFont(new Font("΢���ź�", 0, 12));
		deleteButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		deleteButton.setBounds(110, 10, 70, 30);
		deleteButton.setEnabled(false);
		deleteButton.addActionListener(new StudentDeleteAction(this));
		
		updateButton = new JButton("�޸�");
		updateButton.setForeground(Color.WHITE);
		updateButton.setFont(new Font("΢���ź�", 0, 12));
		updateButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
		updateButton.setBounds(190, 10, 70, 30);
		updateButton.setEnabled(false);
		updateButton.addActionListener(new StudentUpdateBAction(this));
						
		add(addButton);
		add(deleteButton);
		add(updateButton);
	}
	
	public void creatList(){
		if (mainFram.user.getPower()) {
			addButton.setEnabled(true);
		}
		String[] columnNames = {"ѧ��", "����", "ѧԺ��ϵ��", "רҵ", "�꼶", "�Ա�", "�绰"};
		IStudentDao iStudentDao = new IStudentDao();
		Student[] students = iStudentDao.list(mainFram.user);
		
		Object[][] objects = new Object[students.length][7];
		for(int i = 0; i < students.length; i++){
			objects[i][0] = students[i].getId();
			objects[i][1] = students[i].getName();
			objects[i][2] = students[i].getCollege();
			objects[i][3] = students[i].getMajor();
			objects[i][4] = students[i].getGrade();
			objects[i][5] = students[i].getGender();
			objects[i][6] = students[i].getPhone();
		}
		
		studentTable = new JTable(objects, columnNames);
		studentTable.getSelectionModel().addListSelectionListener(new StudentListListenr(mainFram.user, this));
		
		scrollPane = new JScrollPane(studentTable);
		scrollPane.setBounds(0, 50, 670, 400);
		
		add(scrollPane);
	}
}
