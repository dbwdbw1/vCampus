package vCampus.client.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JLabel;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;
import org.jdesktop.swingx.JXImagePanel;

import vCampus.client.control.CommodityDeleteAction;
import vCampus.client.control.CommodityPurchaseBAction;
import vCampus.client.view.utility.RoundedPanel;
import vCampus.common.baseClass.Commodity;

public class CommodityItemPanel extends RoundedPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public CommodityItemPanel(CommodityPanel commodityPanel, Commodity commodity) {
		super(15);
		setBackground(new Color(236, 236, 236));
		setLayout(null);
		
		setPreferredSize(new Dimension(190, 250));
		JXImagePanel jxImagePanel = null;
		try {
			jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/Hot.png"));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}		
		jxImagePanel.setBounds(37, 20, 115, 120);
		
		JLabel nameLable = new JLabel(commodity.getName());
		nameLable.setFont(new Font("΢���ź�", 0, 12));
		nameLable.setBounds(20, 145, 150, 20);
		
		JLabel priceLable = new JLabel("��" + commodity.getPrice());
		priceLable.setFont(new Font("΢���ź�", 0, 12));
		priceLable.setBounds(20, 165, 70, 20);
		
		JLabel salesLable = new JLabel("������" + commodity.getSales());
		salesLable.setFont(new Font("΢���ź�", 0, 12));
		salesLable.setBounds(110, 165, 150, 20);
		
		JLabel detailLable = new JLabel("��飺" + commodity.getDetail());
		detailLable.setFont(new Font("΢���ź�", 0, 12));
		detailLable.setBounds(20, 185, 160, 20);
		
		JButton purchaseButton = new JButton("����");
		purchaseButton.setForeground(Color.WHITE);
		purchaseButton.setFont(new Font("΢���ź�", 0, 11));
		purchaseButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		purchaseButton.addActionListener(new CommodityPurchaseBAction(commodityPanel, commodity));
				
		JButton deleteButton = new JButton("�¼�");
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setFont(new Font("΢���ź�", 0, 11));
		deleteButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		deleteButton.setBounds(100, 210, 70, 26);
		deleteButton.addActionListener(new CommodityDeleteAction(commodityPanel, commodity));
		
		if (commodityPanel.mainFram.user.getPower()) {
			purchaseButton.setBounds(20, 210, 70, 26);
			add(deleteButton);
		}
		else {
			purchaseButton.setBounds(60, 210, 70, 26);
		}
		
		add(jxImagePanel);
		add(nameLable);
		add(priceLable);
		add(salesLable);
		add(detailLable);
		add(purchaseButton);					
				
	}
		
}
