package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.DormListListenr;
import vCampus.client.dao.IDormDao;
import vCampus.common.baseClass.Dorm;
import vCampus.common.baseClass.User;

public class DormPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private User user;
	
	public JButton stopButton;
	
	public JTable dormTable;

	public DormPanel(User user) {
		super();
		this.user = user;
		setLayout(null);
		
		stopButton = new JButton("ͣ����ˮ");
		stopButton.setForeground(Color.WHITE);
		stopButton.setFont(new Font("΢���ź�", 0, 12));
		stopButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		stopButton.setBounds(20, 10, 100, 30);
		stopButton.setEnabled(false);
		
		add(stopButton);
	}
	
	public void creatList(){
		String[] columnNames = {"����", "ѧ��1", "ѧ��2", "ѧ��3", "ѧ��4", "����Ӧ��ˮ���", "��ˮ��Ӧ"};
		IDormDao iDormDao = new IDormDao();
		Dorm[] dorms = iDormDao.list(user);
		
		Object[][] objects = new Object[dorms.length][7];
		for(int i = 0; i < dorms.length; i++){
			objects[i][0] = dorms[i].getName();
			objects[i][1] = dorms[i].getStudent1Name();
			objects[i][2] = dorms[i].getStudent2Name();
			objects[i][3] = dorms[i].getStudent3Name();
			objects[i][4] = dorms[i].getStudent4Name();
			objects[i][5] = dorms[i].getUtilities();
			objects[i][6] = dorms[i].getHotWater() ? "������Ӧ" : "ֹͣ��Ӧ";
		}
		
		dormTable = new JTable(objects, columnNames);
		dormTable.getSelectionModel().addListSelectionListener(new DormListListenr(user, this));
		
		JScrollPane scrollPane = new JScrollPane(dormTable);
		scrollPane.setBounds(0, 50, 670, 400);
		
		add(scrollPane);
	}
}
