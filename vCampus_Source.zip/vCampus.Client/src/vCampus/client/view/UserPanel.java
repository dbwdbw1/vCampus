package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;
import org.jdesktop.swingx.JXImagePanel;

import vCampus.client.view.utility.RoundedPanel;
import vCampus.common.baseClass.User;

public class UserPanel extends RoundedPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public User user;
	
	public MainFram mainFram;
	private UserPanel userPanel;
	
	private ChargeDialog chargeDialog;
	
	private JXImagePanel avatar;
	private JLabel uid;
	private JLabel power;
	private JLabel balance;
	private JLabel domName;
	private JLabel bookinfo;
	private JLabel subjectinfo;
	private JButton chargeButton;

	public UserPanel(MainFram mainFram) {
		super(20);
		
		this.mainFram = mainFram;
		userPanel = this;
		this.user = mainFram.user;
		setBackground(new Color(236, 236, 236));
		
		setLayout(null);
		try {
			avatar = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/timg.jpg"));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		avatar.setBounds(50, 20, 150, 150);
		avatar.setBorder(BorderFactory.createEtchedBorder());		
		
		uid = new JLabel();
		power = new JLabel();
		balance = new JLabel();
		domName = new JLabel();
		bookinfo = new JLabel();
		subjectinfo = new JLabel();
		
		chargeButton = new JButton("��ֵ");
		chargeButton.setForeground(Color.WHITE);
		chargeButton.setFont(new Font("΢���ź�", 0, 11));
		chargeButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		
		add(avatar);
	}
	
	public void creatUserInfo(){
		uid.setText("�û�id��" + user.getId());
		uid.setFont(new Font("΢���ź�", 0, 12));
		uid.setBounds(20, 200, 150, 25);
		
		power.setText("Ȩ�ޣ�" + (user.getPower()?"����Ա":"�ǹ���Ա"));
		power.setFont(new Font("΢���ź�", 0, 12));
		power.setBounds(20, 230, 150, 25);
		
		balance.setText("�˻���" + user.getBalance());
		balance.setFont(new Font("΢���ź�", 0, 12));
		balance.setBounds(20, 260, 150, 25);
		
		chargeButton.setBounds(150, 260, 50, 25);
		chargeButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				chargeDialog = new ChargeDialog(userPanel);
				chargeDialog.setVisible(true);
				
			}
		});
		
		domName.setText("���᣺" + user.getDomId());
		domName.setFont(new Font("΢���ź�", 0, 12));
		domName.setBounds(20, 290, 150, 25);
		
		bookinfo.setText("δ���飺" + user.getBookInfo().size() + "��");
		bookinfo.setFont(new Font("΢���ź�", 0, 12));
		bookinfo.setBounds(20, 320, 150, 25);
		
		subjectinfo.setText("��ѡ�Σ�" + user.getSubjectInfo().size() + "��");
		subjectinfo.setFont(new Font("΢���ź�", 0, 12));
		subjectinfo.setBounds(20, 350, 150, 25);
		
		add(uid);
		add(power);
		add(balance);
		add(chargeButton);
		add(domName);
		add(bookinfo);
		add(subjectinfo);
	}
}
