package vCampus.client.view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JLabel;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;
import org.jdesktop.swingx.JXImagePanel;

import vCampus.client.control.BookRetreatAction;
import vCampus.client.control.BookSelectAction;
import vCampus.client.view.utility.RoundedPanel;
import vCampus.common.baseClass.Book;

public class BookItemPanel extends RoundedPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	public BookItemPanel(BookPanel bookPanel, Book book) {
		super(15);
		setBackground(new Color(236, 236, 236));
		setLayout(null);
		
		setPreferredSize(new Dimension(190, 250));
		JXImagePanel jxImagePanel = null;
		switch (book.getId()) {
		case "0":
			try {
				jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/C++.jpg"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		case "1":
			try {
				jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/C.jpg"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		case "2":
			try {
				jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/CS.jpg"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		case "3":
			try {
				jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/Data.jpg"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		default:
			try {
				jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/Data.jpg"));
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
			break;
		}
		jxImagePanel.setBounds(37, 20, 115, 161);
		
		JLabel nameLable = new JLabel(book.getName());
		nameLable.setFont(new Font("΢���ź�", 0, 12));
		nameLable.setBounds(20, 185, 150, 20);
		
		JButton selectButton = new JButton("����");
	    selectButton.setForeground(Color.WHITE);
	    selectButton.setFont(new Font("΢���ź�", 0, 11));
		selectButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		selectButton.setBounds(20, 210, 70, 26);
		selectButton.addActionListener(new BookSelectAction(bookPanel, book));
		
		JButton retreatButton = new JButton("�˻�");
		retreatButton.setForeground(Color.WHITE);
		retreatButton.setFont(new Font("΢���ź�", 0, 11));
		retreatButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		retreatButton.setBounds(100, 210, 70, 26);
		retreatButton.addActionListener(new BookRetreatAction(bookPanel, book));
		
		add(jxImagePanel);
		add(nameLable);
		add(selectButton);
		add(retreatButton);
		
		for(int i = 0; i < bookPanel.mainFram.user.getBookInfo().size(); i++){
			if (bookPanel.mainFram.user.getBookInfo().get(i).toString().equals(book.getId())) {
				retreatButton.setEnabled(true);
				selectButton.setEnabled(false);
				return;
			}			
		}
		retreatButton.setEnabled(false);
		selectButton.setEnabled(true);
				
	}
		
}
