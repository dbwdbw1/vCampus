package vCampus.client.view;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;
import org.jdesktop.swingx.JXImagePanel;

import vCampus.client.control.LoginAction;
import vCampus.client.control.RegistBAction;

public class LoginDialog extends JDialog {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public MainFram mainFram;
	
	public RegistDialog registDialog;
	
	public LoginDialog(MainFram Fram) {
		super(Fram, "��¼", true);
		
		this.mainFram = Fram;
		
		setBounds(330, 260, 300, 280);
		
		JXImagePanel jxImagePanel = null;
		try {
			jxImagePanel = new JXImagePanel(new URL("file:" + System.getProperty("user.dir") + "/res/Personal_Background.png"));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		jxImagePanel.setBounds(0, 0, 300, 104);
		
		JLabel idLabel = new JLabel("�˺�");
		idLabel.setFont(new Font("΢���ź�", 0, 14));
		idLabel.setBounds(20, 115, 50, 28);
		
		JTextField idTextField = new JTextField();
		idTextField.setFont(new Font("΢���ź�", 0, 12));
		idTextField.setBounds(70, 115, 190, 28);
		
		
		JLabel passwordLabel = new JLabel("����");
		passwordLabel.setFont(new Font("΢���ź�", 0, 14));
		passwordLabel.setBounds(20, 160, 50, 28);		
		
		JPasswordField passwordTextField = new JPasswordField();
		passwordTextField.setFont(new Font("΢���ź�", 0, 14));
		passwordTextField.setBounds(70, 160, 190, 28);
		
		JButton loginButton = new JButton("��¼");
	    loginButton.setForeground(Color.WHITE);
	    loginButton.setFont(new Font("΢���ź�", 0, 12));
		loginButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		loginButton.setBounds(50, 200, 70, 30);
		loginButton.addActionListener(new LoginAction(idTextField, passwordTextField, this));
		
		JButton registButton = new JButton("ע��");
		registButton.setForeground(Color.WHITE);
		registButton.setFont(new Font("΢���ź�", 0, 12));
		registButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.blue));
		registButton.setBounds(170, 200, 70, 30);
		registButton.addActionListener(new RegistBAction(this));
		
		
		
		Container container = getContentPane();
		container.setLayout(null);
		
		container.add(jxImagePanel);
		container.add(idLabel);
		container.add(idTextField);
		container.add(passwordLabel);
		container.add(passwordTextField);
		container.add(loginButton);
		container.add(registButton);
	}
}
