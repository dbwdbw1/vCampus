package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.CommodityAddBAction;
import vCampus.client.dao.ICommodityDao;
import vCampus.common.baseClass.Commodity;

public class CommodityPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MainFram mainFram;
	
	public JButton purchaseButton;
	public JButton addButton;
	public JButton deleteButton;
	
	public JPanel commodityList;
	
	public JScrollPane scrollPane;
	
	public CommodityPanel(MainFram mainFram) {
		super();
		this.mainFram = mainFram;
		setLayout(null);			
		
		addButton = new JButton("�ϼ�");
		addButton.setForeground(Color.WHITE);
		addButton.setFont(new Font("΢���ź�", 0, 12));
		addButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.lightBlue));
		addButton.setBounds(20, 10, 70, 30);
		addButton.setEnabled(false);	
		addButton.addActionListener(new CommodityAddBAction(this));
		
		add(addButton);
	}
	
	public void creatList() {
		commodityList = new JPanel();
		commodityList.setLayout(new GridLayout(0, 3, 35, 20));

		ICommodityDao iCommodityDao = new ICommodityDao();
		Commodity commoditys[] = iCommodityDao.list(mainFram.user);
		CommodityItemPanel commodityItemPanels[] = new CommodityItemPanel[commoditys.length];
		for(int i = 0; i < commoditys.length; i++){
			commodityItemPanels[i] = new CommodityItemPanel(this, commoditys[i]);
			commodityList.add(commodityItemPanels[i]);
		}		
		
		if (mainFram.user.getPower()) {
			addButton.setEnabled(true);
		}
		
		scrollPane = new JScrollPane(commodityList);
		scrollPane.setBounds(0, 50, 670, 400);
		add(scrollPane);
	}

}
