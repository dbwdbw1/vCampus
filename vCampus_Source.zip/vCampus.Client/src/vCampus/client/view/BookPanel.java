package vCampus.client.view;

import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import vCampus.client.dao.IBookDao;
import vCampus.common.baseClass.Book;

public class BookPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MainFram mainFram;
	
	public JButton selectButton;
	public JButton retreatButton;
	
	public JScrollPane scrollPane;
	public JPanel bookList;
	
	public BookPanel(MainFram mainFram) {
		super();
		this.mainFram = mainFram;
		setLayout(null);			
	}
	
	public void creatList() {
		bookList = new JPanel();
		bookList.setLayout(new GridLayout(0, 3, 35, 20));
		
		IBookDao iBookDao = new IBookDao();
		Book books[] = iBookDao.list(mainFram.user);
		BookItemPanel bookItemPanels[] = new BookItemPanel[books.length];
		for(int i = 0; i < books.length; i++){
			bookItemPanels[i] = new BookItemPanel(this, books[i]);
			bookList.add(bookItemPanels[i]);
		}		
		
		scrollPane = new JScrollPane(bookList);
		scrollPane.setBounds(0, 50, 670, 450);
		add(scrollPane);
	}

}
