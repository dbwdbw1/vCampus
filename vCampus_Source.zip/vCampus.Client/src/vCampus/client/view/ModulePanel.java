package vCampus.client.view;

import java.awt.Color;

import javax.swing.JTabbedPane;

import vCampus.client.view.utility.RoundedPanel;

public class ModulePanel extends RoundedPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public MainFram mainFram;
	
	private JTabbedPane tabbedPane;
	
	private StudentPanel studentPanel;
	private SubjectPanel subjectPanel;
	private BookPanel bookPanel;
	private CommodityPanel commodityPanel;
	private DormPanel dormPanel;

	public ModulePanel(MainFram mainFram) {
		super(20);
		this.mainFram = mainFram;
		
		setBackground(new Color(236, 236, 236));
		setLayout(null);
		
		tabbedPane = new JTabbedPane();
		tabbedPane.setBounds(0, 0, 670, 660);
						
		studentPanel = new StudentPanel(mainFram);
		subjectPanel = new SubjectPanel(mainFram);
		bookPanel = new BookPanel(mainFram);	
		commodityPanel = new CommodityPanel(mainFram);
		dormPanel = new DormPanel(mainFram.user);
		
	}
	
	public void creatTabbedPanel(){
		studentPanel.creatList();
		tabbedPane.add((mainFram.user.getPower())?"ѧ������":"ѧ����Ϣ", studentPanel);
		subjectPanel.creatList();
		tabbedPane.add("ѡ�ι���", subjectPanel);
		bookPanel.creatList();
		tabbedPane.add("ͼ���", bookPanel);
		commodityPanel.creatList();
		tabbedPane.add("�����̵�", commodityPanel);
		dormPanel.creatList();
		tabbedPane.add((mainFram.user.getPower())?"�������":"������Ϣ", dormPanel);
		
		add(tabbedPane);		
	}
}
