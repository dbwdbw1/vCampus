package vCampus.client.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.jb2011.lnf.beautyeye.ch3_button.BEButtonUI;

import vCampus.client.control.SubjectAddBAction;
import vCampus.client.control.SubjectDeleteAction;
import vCampus.client.control.SubjectListListenr;
import vCampus.client.control.SubjectRetreatAction;
import vCampus.client.control.SubjectSelectAction;
import vCampus.client.dao.ISubjectDao;
import vCampus.common.baseClass.Subject;

public class SubjectPanel extends JPanel {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MainFram mainFram;
	
	public JButton selectButton;
	public JButton retreatButton;
	public JButton addButton;
	public JButton deleteButton;
	
	public JTable subjectTable;
	public JScrollPane scrollPane;

	public SubjectPanel(MainFram mainFram) {
		super();
		this.mainFram = mainFram;
		setLayout(null);	
		
		selectButton = new JButton("ѡ��");
		selectButton.setForeground(Color.WHITE);
		selectButton.setFont(new Font("΢���ź�", 0, 12));
		selectButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		selectButton.setBounds(20, 10, 70, 30);
		selectButton.setEnabled(false);
		selectButton.addActionListener(new SubjectSelectAction(this));
		
		retreatButton = new JButton("�˿�");
		retreatButton.setForeground(Color.WHITE);
		retreatButton.setFont(new Font("΢���ź�", 0, 12));
		retreatButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		retreatButton.setBounds(110, 10, 70, 30);
		retreatButton.setEnabled(false);
		retreatButton.addActionListener(new SubjectRetreatAction(this));
		
		addButton = new JButton("����");
		addButton.setForeground(Color.WHITE);
	    addButton.setFont(new Font("΢���ź�", 0, 12));
		addButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.green));
		addButton.setBounds(190, 10, 70, 30);
		addButton.setEnabled(false);
		addButton.addActionListener(new SubjectAddBAction(this));
		
		deleteButton = new JButton("�Ƴ�");
		deleteButton.setForeground(Color.WHITE);
		deleteButton.setFont(new Font("΢���ź�", 0, 12));
		deleteButton.setUI(new BEButtonUI().setNormalColor(BEButtonUI.NormalColor.red));
		deleteButton.setBounds(270, 10, 70, 30);
		deleteButton.setEnabled(false);	
		deleteButton.addActionListener(new SubjectDeleteAction(this));
						
		add(addButton);
		add(deleteButton);
		add(selectButton);
		add(retreatButton);
	}
	
	public void creatList(){
		if (mainFram.user.getPower()) {
			addButton.setEnabled(true);
		}
		String[] columnNames = {"�γ�id", "����", "�ο���ʦ", "�Ͽ�ʱ��", "����", "���", "�Ƿ���ѡ"};
		ISubjectDao iSubjectDao = new ISubjectDao();
		Subject[] subjects = iSubjectDao.list(mainFram.user);
		
		Object[][] objects = new Object[subjects.length][7];
		for(int i = 0; i < subjects.length; i++){
			objects[i][0] = subjects[i].getId();
			objects[i][1] = subjects[i].getName();
			objects[i][2] = subjects[i].getTeacher();
			objects[i][3] = subjects[i].getTime();
			objects[i][4] = subjects[i].getClassroom();
			objects[i][5] = subjects[i].getDetail();
			objects[i][6] = "δѡ";
			for( int j = 0; j < mainFram.user.getSubjectInfo().size(); j++){
				if (mainFram.user.getSubjectInfo().get(j).toString().equals(subjects[i].getId())) {
					objects[i][6] = "��ѡ";
					break;
				}
			}
		}
		
		subjectTable = new JTable(objects, columnNames);
		subjectTable.getSelectionModel().addListSelectionListener(new SubjectListListenr(mainFram.user, this));
		
		scrollPane = new JScrollPane(subjectTable);
		scrollPane.setBounds(0, 50, 670, 400);
		
		add(scrollPane);
	}
}
