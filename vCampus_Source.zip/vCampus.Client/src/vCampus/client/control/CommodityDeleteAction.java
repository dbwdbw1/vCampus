package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.ICommodityDao;
import vCampus.client.view.CommodityPanel;
import vCampus.common.baseClass.Commodity;

public class CommodityDeleteAction implements ActionListener {
	
	private CommodityPanel commodityPanel;
	private Commodity commodity;
	
	public CommodityDeleteAction(CommodityPanel commodityPanel, Commodity commodity) {
		this.commodityPanel = commodityPanel;
		this.commodity = commodity;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		ICommodityDao iCommodityDao = new ICommodityDao();
		Boolean result = iCommodityDao.delete(commodityPanel.mainFram.user, commodity.getId());
		if (result) {
			commodityPanel.remove(commodityPanel.scrollPane);
			commodityPanel.creatList();

			JOptionPane.showMessageDialog(commodityPanel, "�¼ܳɹ�");			
		}
		else {
			JOptionPane.showMessageDialog(commodityPanel, "�¼�ʧ�ܣ�������������");
		}

	}

}
