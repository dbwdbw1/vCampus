package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.ISubjectDao;
import vCampus.client.view.SubjectPanel;

public class SubjectRetreatAction implements ActionListener {
	private SubjectPanel subjectPanel;
	
	public SubjectRetreatAction(SubjectPanel subjectPanel) {
		this.subjectPanel = subjectPanel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ISubjectDao iSubjectDao = new ISubjectDao();
		String id = subjectPanel.subjectTable.getValueAt(subjectPanel.subjectTable.getSelectedRow(), 0).toString();
		Boolean result = iSubjectDao.retreat(subjectPanel.mainFram.user, id);
		if (result) {
			for(int i = 0; i < subjectPanel.mainFram.user.getSubjectInfo().size(); i++){
				if (subjectPanel.mainFram.user.getSubjectInfo().get(i).toString().equals(id)) {
					subjectPanel.mainFram.user.getSubjectInfo().remove(i);
					break;
				}
			}
			subjectPanel.remove(subjectPanel.scrollPane);
			subjectPanel.creatList();
			JOptionPane.showMessageDialog(subjectPanel.mainFram, "�˿γɹ�");
		}
		else {
			JOptionPane.showMessageDialog(subjectPanel.mainFram, "ѡ��ʧ�ܣ�������������");
		}
	}

}
