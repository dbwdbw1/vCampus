package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import vCampus.client.dao.IStudentDao;
import vCampus.client.view.StudentAddDialog;
import vCampus.common.baseClass.Student;

public class StudentAddAction implements ActionListener {
	private StudentAddDialog studentAddDialog;
		
	private JTextField idTextField;
	private JTextField nameTextField;
	private JTextField collegeTextField;
	private JTextField majorTextField;
	private JSpinner gradeSpinner;
	private JRadioButton manButton;
	private JRadioButton womanButton;
	private ButtonGroup genderGroup;
	private JTextField telTextField;
	
	public StudentAddAction(StudentAddDialog studentAddDialog, JTextField idTextField, JTextField nameTextField, JTextField collegeTextField, JTextField majorTextField, JSpinner gradeSpinner, JRadioButton manButton, JRadioButton womanButton, ButtonGroup genderGroup, JTextField telTextField) {
		this.studentAddDialog = studentAddDialog;
		
		this.idTextField = idTextField;
		this.nameTextField = nameTextField;
		this.collegeTextField = collegeTextField;
		this.majorTextField = majorTextField;
		this.gradeSpinner = gradeSpinner;
		this.manButton = manButton;
		this.womanButton = womanButton;
		this.genderGroup = genderGroup;
		this.telTextField = telTextField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (idTextField.getText() == null || idTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentAddDialog, "ѧ�Ų���Ϊ��");
			return;
		}
		if (nameTextField.getText() == null || nameTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentAddDialog, "��������Ϊ��");
			return;
		}
		if (collegeTextField.getText() == null || collegeTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentAddDialog, "ѧԺ����Ϊ��");
			return;
		}
		if (majorTextField.getText() == null || majorTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentAddDialog, "רҵ����Ϊ��");
			return;
		}
		if (telTextField.getText() == null || telTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentAddDialog, "�绰����Ϊ��");
			return;
		}
		
		IStudentDao iStudentDao = new IStudentDao();
		String gender;
		if (genderGroup.isSelected(manButton.getModel())) {
			gender = "��";
		}
		else if (genderGroup.isSelected(womanButton.getModel())) {
			gender = "Ů";
		}
		else{
			JOptionPane.showMessageDialog(studentAddDialog, "��ѡ���Ա�");
			return;
		}
		Student student = new Student(idTextField.getText(), nameTextField.getText(), collegeTextField.getText(), majorTextField.getText(), Integer.parseInt(gradeSpinner.getModel().getValue().toString()), gender, telTextField.getText());
		Boolean result = iStudentDao.add(studentAddDialog.studentPanel.mainFram.user, student );
		if (result) {			
			studentAddDialog.studentPanel.remove(studentAddDialog.studentPanel.scrollPane);
			studentAddDialog.studentPanel.creatList();		
			JOptionPane.showMessageDialog(studentAddDialog, "���ӳɹ�");
			studentAddDialog.dispose();
		}
		else {
			JOptionPane.showMessageDialog(studentAddDialog, "����ʧ�ܣ�������������");
		}
	}

}
