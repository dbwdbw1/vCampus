package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vCampus.client.view.SubjectAddDialog;
import vCampus.client.view.SubjectPanel;

public class SubjectAddBAction implements ActionListener {
	public SubjectPanel subjectPanel;

	public SubjectAddBAction(SubjectPanel subjectPanel) {
		this.subjectPanel = subjectPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		SubjectAddDialog subjectAddDialog = new SubjectAddDialog(subjectPanel);
		subjectAddDialog.setVisible(true);
	}

}
