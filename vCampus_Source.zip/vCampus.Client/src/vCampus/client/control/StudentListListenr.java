package vCampus.client.control;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import vCampus.client.view.StudentPanel;
import vCampus.common.baseClass.User;

public class StudentListListenr implements ListSelectionListener {
	
	private User user;
	
	private StudentPanel studentPanel;
	
	public StudentListListenr( User user, StudentPanel panel) {
		this.user = user;
		this.studentPanel = panel;
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		if (user.getPower()) {
			studentPanel.deleteButton.setEnabled(true);
			studentPanel.updateButton.setEnabled(true);
		}
		else if (studentPanel.studentTable.getValueAt(studentPanel.studentTable.getSelectedRow(), 0).toString().equals(user.getStudentId())) {
			studentPanel.updateButton.setEnabled(true);
		}

	}

}
