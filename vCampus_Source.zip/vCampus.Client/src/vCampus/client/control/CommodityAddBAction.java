package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vCampus.client.view.CommodityAddDialog;
import vCampus.client.view.CommodityPanel;

public class CommodityAddBAction implements ActionListener {
	public CommodityPanel commodityPanel;

	public CommodityAddBAction(CommodityPanel commodityPanel) {
		this.commodityPanel = commodityPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		CommodityAddDialog commodityAddDialog= new CommodityAddDialog(commodityPanel);
		commodityAddDialog.setVisible(true);
	}

}
