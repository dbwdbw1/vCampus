package vCampus.client.control;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import vCampus.client.view.SubjectPanel;
import vCampus.common.baseClass.User;

public class SubjectListListenr implements ListSelectionListener {
	private User user;
	
	private SubjectPanel subjectPanel;
	
	public SubjectListListenr( User user, SubjectPanel panel) {
		this.user = user;
		this.subjectPanel = panel;
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		if (user.getPower()) {
			subjectPanel.addButton.setEnabled(true);
			subjectPanel.deleteButton.setEnabled(true);
		}
		if (subjectPanel.subjectTable.getValueAt(subjectPanel.subjectTable.getSelectedRow(), 6).equals("��ѡ")) {
			subjectPanel.selectButton.setEnabled(false);
			subjectPanel.retreatButton.setEnabled(true);
		}
		else {
			subjectPanel.selectButton.setEnabled(true);
			subjectPanel.retreatButton.setEnabled(false);
		}
	}

}
