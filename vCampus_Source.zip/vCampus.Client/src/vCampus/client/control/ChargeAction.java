package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import vCampus.client.dao.ICommodityDao;
import vCampus.client.view.ChargeDialog;
import vCampus.common.baseClass.User;

public class ChargeAction implements ActionListener {
	
	private User user;
	
	private JTextField textField;
	private ChargeDialog chargeDialog;
	
	public ChargeAction(User user, JTextField textField, ChargeDialog chargeDialog) {
		this.user = user;
		this.textField = textField;
		this.chargeDialog = chargeDialog;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		int money = Integer.parseInt(textField.getText());
		if ( money <= 0) {
			JOptionPane.showMessageDialog(chargeDialog, "��������ȷ�����֣�");
		}
		else {
			ICommodityDao iCommodityDao = new ICommodityDao();
			Boolean result = iCommodityDao.charge(user, Integer.parseInt(textField.getText()));
			if (result) {
				JOptionPane.showMessageDialog(chargeDialog, "��ֵ�ɹ�");
				user.setBalance(user.getBalance() + Integer.parseInt(textField.getText()));
				chargeDialog.userPanel.creatUserInfo();
				chargeDialog.dispose();
			}
			else {
				JOptionPane.showMessageDialog(chargeDialog, "��ֵʧ�ܣ���������״̬");
			}
		}

	}

}
