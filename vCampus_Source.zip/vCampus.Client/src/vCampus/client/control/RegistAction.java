package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import vCampus.client.dao.IUserDao;
import vCampus.client.view.RegistDialog;
import vCampus.common.baseClass.User;

public class RegistAction implements ActionListener {
	
	private RegistDialog registDialog;
	
	private JTextField idField;
	private JPasswordField passwordField;
	private JPasswordField repasswordField;
	private JTextField domIdField;
	
	public RegistAction(JTextField textField, JPasswordField passwordField, JPasswordField rePasswordField, JTextField domIdField, RegistDialog registDialog) {
		this.idField = textField;
		this.passwordField = passwordField;
		this.repasswordField = rePasswordField;
		this.domIdField = domIdField;
		
		this.registDialog = registDialog;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if (idField.getText() == null || idField.getText().equals("")) {
			JOptionPane.showMessageDialog(registDialog, "�˺Ų���Ϊ��");
			return;
		}
		
		if (passwordField.getPassword() == null || passwordField.getPassword().length == 0) {
			JOptionPane.showMessageDialog(registDialog, "���벻��Ϊ��");
			return;
		}
		
		if (repasswordField.getPassword() == null || repasswordField.getPassword().length == 0) {
			JOptionPane.showMessageDialog(registDialog, "ȷ�����벻��Ϊ��");
			return;
		}
		if (domIdField.getText() == null || domIdField.getText().equals("")) {
			JOptionPane.showMessageDialog(registDialog, "���᲻��Ϊ��");
			return;
		}
		
		
		if (String.valueOf(passwordField.getPassword()).equals(String.valueOf(repasswordField.getPassword()))) {
			IUserDao iUserDao = new IUserDao();
			@SuppressWarnings("rawtypes")
			User user = new User(idField.getText(), String.valueOf(passwordField.getPassword()), false, 0, idField.getText(), domIdField.getText(), new ArrayList<String>(), new ArrayList<String>(), new ArrayList<List>());
			Boolean result = iUserDao.register(user);
			if(result){
				JOptionPane.showMessageDialog(registDialog, "ע��ɹ����뷵�ص�¼");
				registDialog.dispose();
			}
			else {
				JOptionPane.showMessageDialog(registDialog, "ע��ʧ�ܣ����������Ƿ�����");
			}
		}
		else {
			JOptionPane.showMessageDialog(registDialog, "ȷ�����������벻��ͬ������������");
			return;
		}

	}

}
