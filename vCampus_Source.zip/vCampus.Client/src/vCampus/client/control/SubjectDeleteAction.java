package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.ISubjectDao;
import vCampus.client.view.SubjectPanel;

public class SubjectDeleteAction implements ActionListener {
	
	private SubjectPanel subjectPanel;
	
	public SubjectDeleteAction(SubjectPanel subjectPanel) {
		this.subjectPanel = subjectPanel;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		ISubjectDao iSubjectDao = new ISubjectDao();
		Boolean result = iSubjectDao.delete(subjectPanel.mainFram.user, subjectPanel.subjectTable.getValueAt(subjectPanel.subjectTable.getSelectedRow(),0).toString());
		if (result) {
			subjectPanel.remove(subjectPanel.scrollPane);
			subjectPanel.creatList();
			subjectPanel.updateUI();

			JOptionPane.showMessageDialog(subjectPanel, "ɾ���ɹ�");			
		}
		else {
			JOptionPane.showMessageDialog(subjectPanel, "ɾ��ʧ�ܣ�������������");
		}

	}

}
