package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vCampus.client.view.StudentUpdateDialog;
import vCampus.client.view.StudentPanel;

public class StudentUpdateBAction implements ActionListener {
	public StudentPanel studentPanel;

	public StudentUpdateBAction(StudentPanel studentPanel) {
		this.studentPanel = studentPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		StudentUpdateDialog StudentUpdateDialog= new StudentUpdateDialog(studentPanel);
		StudentUpdateDialog.setVisible(true);
	}

}
