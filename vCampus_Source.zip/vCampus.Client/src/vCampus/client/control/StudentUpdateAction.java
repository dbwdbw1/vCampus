package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;

import vCampus.client.dao.IStudentDao;
import vCampus.client.view.StudentUpdateDialog;
import vCampus.common.baseClass.Student;

public class StudentUpdateAction implements ActionListener {
	private StudentUpdateDialog studentUpdateDialog;
		
	private JTextField idTextField;
	private JTextField nameTextField;
	private JTextField collegeTextField;
	private JTextField majorTextField;
	private JSpinner gradeSpinner;
	private JRadioButton manButton;
	private JRadioButton womanButton;
	private ButtonGroup genderGroup;
	private JTextField telTextField;
	
	public StudentUpdateAction(StudentUpdateDialog studentUpdateDialog, JTextField idTextField, JTextField nameTextField, JTextField collegeTextField, JTextField majorTextField, JSpinner gradeSpinner, JRadioButton manButton, JRadioButton womanButton, ButtonGroup genderGroup, JTextField telTextField) {
		this.studentUpdateDialog = studentUpdateDialog;
		
		this.idTextField = idTextField;
		this.nameTextField = nameTextField;
		this.collegeTextField = collegeTextField;
		this.majorTextField = majorTextField;
		this.gradeSpinner = gradeSpinner;
		this.manButton = manButton;
		this.womanButton = womanButton;
		this.genderGroup = genderGroup;
		this.telTextField = telTextField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (idTextField.getText() == null || idTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentUpdateDialog, "ѧ�Ų���Ϊ��");
			return;
		}
		if (nameTextField.getText() == null || nameTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentUpdateDialog, "��������Ϊ��");
			return;
		}
		if (collegeTextField.getText() == null || collegeTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentUpdateDialog, "ѧԺ����Ϊ��");
			return;
		}
		if (majorTextField.getText() == null || majorTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentUpdateDialog, "רҵ����Ϊ��");
			return;
		}
		if (telTextField.getText() == null || telTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(studentUpdateDialog, "�绰����Ϊ��");
			return;
		}
		
		IStudentDao iStudentDao = new IStudentDao();
		String gender;
		if (genderGroup.isSelected(manButton.getModel())) {
			gender = "��";
		}
		else if (genderGroup.isSelected(womanButton.getModel())) {
			gender = "Ů";
		}
		else{
			JOptionPane.showMessageDialog(studentUpdateDialog, "��ѡ���Ա�");
			return;
		}
		Student student = new Student(idTextField.getText(), nameTextField.getText(), collegeTextField.getText(), majorTextField.getText(), Integer.parseInt(gradeSpinner.getModel().getValue().toString()), gender, telTextField.getText());
		Boolean result = iStudentDao.update(studentUpdateDialog.studentPanel.mainFram.user, student );
		if (result) {			
			studentUpdateDialog.studentPanel.remove(studentUpdateDialog.studentPanel.scrollPane);
			studentUpdateDialog.studentPanel.creatList();		
			JOptionPane.showMessageDialog(studentUpdateDialog, "�޸ĳɹ�");
			studentUpdateDialog.dispose();
		}
		else {
			JOptionPane.showMessageDialog(studentUpdateDialog, "����ʧ�ܣ�������������");
		}
	}

}
