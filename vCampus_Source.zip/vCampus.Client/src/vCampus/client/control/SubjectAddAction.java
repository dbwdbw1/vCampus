package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import vCampus.client.dao.ISubjectDao;
import vCampus.client.view.SubjectAddDialog;
import vCampus.common.baseClass.Subject;

public class SubjectAddAction implements ActionListener {
	private SubjectAddDialog subjectAddDialog;
		
	private JTextField idTextField;
	private JTextField nameTextField;
	private JTextField teacherTextField;
	private JTextField timeTextField;
	private JTextField classTextField;
	private JTextField detailTextField;
	
	public SubjectAddAction(SubjectAddDialog subjectAddDialog, JTextField idTextField, JTextField nameTextField, JTextField teacherTextField, JTextField timeTextField, JTextField classTextField, JTextField detailTextField) {
		this.subjectAddDialog = subjectAddDialog;
		
		this.idTextField = idTextField;
		this.nameTextField = nameTextField;
		this.teacherTextField = teacherTextField;
		this.timeTextField = timeTextField;
		this.classTextField = classTextField;
		this.detailTextField = detailTextField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (idTextField.getText() == null || idTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(subjectAddDialog, "�γ̴��Ų���Ϊ��");
			return;
		}
		if (nameTextField.getText() == null || nameTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(subjectAddDialog, "���Ʋ���Ϊ��");
			return;
		}
		if (timeTextField.getText() == null || timeTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(subjectAddDialog, "�Ͽ�ʱ�䲻��Ϊ��");
			return;
		}
		if (teacherTextField.getText() == null || teacherTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(subjectAddDialog, "�ο���ʦ����Ϊ��");
			return;
		}
		if (classTextField.getText() == null || classTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(subjectAddDialog, "�Ͽν��Ҳ���Ϊ��");
			return;
		}
		if (detailTextField.getText() == null || detailTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(subjectAddDialog, "��鲻��Ϊ��");
			return;
		}
		
		ISubjectDao iSubjectDao = new ISubjectDao();		
		Subject subject = new Subject(idTextField.getText(), nameTextField.getText(), teacherTextField.getText(), timeTextField.getText(), classTextField.getText(), detailTextField.getText());
		Boolean result = iSubjectDao.add(subjectAddDialog.subjectPanel.mainFram.user, subject );
		if (result) {			
			subjectAddDialog.subjectPanel.remove(subjectAddDialog.subjectPanel.scrollPane);
			subjectAddDialog.subjectPanel.creatList();		
			JOptionPane.showMessageDialog(subjectAddDialog, "���ӳɹ�");
			subjectAddDialog.dispose();
		}
		else {
			JOptionPane.showMessageDialog(subjectAddDialog, "����ʧ�ܣ�������������");
		}
	}

}
