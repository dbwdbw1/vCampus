package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.IBookDao;
import vCampus.client.view.BookPanel;
import vCampus.common.baseClass.Book;

public class BookSelectAction implements ActionListener {
	
	private BookPanel bookPanel;
	private Book book;
	
	public BookSelectAction(BookPanel bookPanel, Book book) {
		this.bookPanel = bookPanel;
		this.book = book;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		IBookDao iBookDao = new IBookDao();
		Boolean result = iBookDao.select(bookPanel.mainFram.user, book.getId());
		if (result) {
			bookPanel.mainFram.user.getBookInfo().add(book.getId());
			bookPanel.mainFram.userPanel.creatUserInfo();
			
			bookPanel.remove(bookPanel.scrollPane);
			bookPanel.creatList();
			
			JOptionPane.showMessageDialog(bookPanel.mainFram, "���ĳɹ�");
		}
		else {
			JOptionPane.showMessageDialog(bookPanel.mainFram, "����ʧ�ܣ�������������");
		}
	}

}
