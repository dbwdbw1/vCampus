package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vCampus.client.view.CommodityPurchaseDialog;
import vCampus.common.baseClass.Commodity;
import vCampus.client.view.CommodityPanel;

public class CommodityPurchaseBAction implements ActionListener {
	public CommodityPanel commodityPanel;
	public Commodity commodity;

	public CommodityPurchaseBAction(CommodityPanel commodityPanel, Commodity commodity) {
		this.commodityPanel = commodityPanel;
		this.commodity = commodity;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		CommodityPurchaseDialog commodityPurchaseDialog= new CommodityPurchaseDialog(commodityPanel, commodity);
		commodityPurchaseDialog.setVisible(true);
	}

}
