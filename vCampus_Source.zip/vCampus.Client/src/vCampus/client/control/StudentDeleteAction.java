package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.IStudentDao;
import vCampus.client.view.StudentPanel;

public class StudentDeleteAction implements ActionListener {
	
	private StudentPanel studentPanel;
	
	public StudentDeleteAction(StudentPanel studentPanel) {
		this.studentPanel = studentPanel;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		IStudentDao iStudentDao = new IStudentDao();
		Boolean result = iStudentDao.delete(studentPanel.mainFram.user, studentPanel.studentTable.getValueAt(studentPanel.studentTable.getSelectedRow(),0).toString());
		if (result) {
			studentPanel.remove(studentPanel.scrollPane);
			studentPanel.creatList();

			JOptionPane.showMessageDialog(studentPanel, "ɾ���ɹ�");			
		}
		else {
			JOptionPane.showMessageDialog(studentPanel, "ɾ��ʧ�ܣ�������������");
		}

	}

}
