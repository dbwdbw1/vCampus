package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import vCampus.client.dao.ICommodityDao;
import vCampus.client.view.CommodityAddDialog;
import vCampus.common.baseClass.Commodity;

public class CommodityAddAction implements ActionListener {
	private CommodityAddDialog commodityAddDialog;
		
	private JTextField idTextField;
	private JTextField nameTextField;
	private JTextField priceTextField;

	private JTextField detailTextField;
	
	public CommodityAddAction(CommodityAddDialog commodityAddDialog, JTextField idTextField, JTextField nameTextField, JTextField priceTextField, JTextField detailTextField) {
		this.commodityAddDialog = commodityAddDialog;
		
		this.idTextField = idTextField;
		this.nameTextField = nameTextField;
		this.priceTextField = priceTextField;
		this.detailTextField = detailTextField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (idTextField.getText() == null || idTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(commodityAddDialog, "��Ʒ���Ų���Ϊ��");
			return;
		}
		if (nameTextField.getText() == null || nameTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(commodityAddDialog, "���Ʋ���Ϊ��");
			return;
		}		
		if (priceTextField.getText() == null || priceTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(commodityAddDialog, "�۸���Ϊ��");
			return;
		}
		if (detailTextField.getText() == null || detailTextField.getText().equals("")) {
			JOptionPane.showMessageDialog(commodityAddDialog, "��鲻��Ϊ��");
			return;
		}
		
		ICommodityDao iCommodityDao = new ICommodityDao();		
		Commodity Commodity = new Commodity(idTextField.getText(), nameTextField.getText(), Integer.parseInt(priceTextField.getText()), detailTextField.getText(), 0);
		Boolean result = iCommodityDao.add(commodityAddDialog.commodityPanel.mainFram.user, Commodity );
		if (result) {			
			commodityAddDialog.commodityPanel.remove(commodityAddDialog.commodityPanel.scrollPane);
			commodityAddDialog.commodityPanel.creatList();		
			JOptionPane.showMessageDialog(commodityAddDialog, "�ϼܳɹ�");
			commodityAddDialog.dispose();
		}
		else {
			JOptionPane.showMessageDialog(commodityAddDialog, "�ϼ�ʧ�ܣ�������������");
		}
	}

}
