package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vCampus.client.view.StudentAddDialog;
import vCampus.client.view.StudentPanel;

public class StudentAddBAction implements ActionListener {
	public StudentPanel studentPanel;

	public StudentAddBAction(StudentPanel studentPanel) {
		this.studentPanel = studentPanel;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		StudentAddDialog studentAddDialog= new StudentAddDialog(studentPanel);
		studentAddDialog.setVisible(true);
	}

}
