package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

import vCampus.client.dao.ICommodityDao;
import vCampus.client.view.CommodityPurchaseDialog;

public class CommodityPurchaseAction implements ActionListener {
	private CommodityPurchaseDialog commodityPurchaseDialog;
		
	private JTextField textField;
	
	public CommodityPurchaseAction(CommodityPurchaseDialog commodityPurchaseDialog, JTextField textField) {
		this.commodityPurchaseDialog = commodityPurchaseDialog;
		
		this.textField = textField;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (textField.getText() == null || textField.getText().equals("") || (Integer.parseInt(textField.getText()) == 0)) {
			JOptionPane.showMessageDialog(commodityPurchaseDialog, "������������Ϊ��");
			return;
		}
		if ((Integer.parseInt(textField.getText()) * commodityPurchaseDialog.commodity.getPrice()) > commodityPurchaseDialog.commodityPanel.mainFram.user.getBalance()) {
			JOptionPane.showMessageDialog(commodityPurchaseDialog, "����");
			return;
		}
		
		ICommodityDao iCommodityDao = new ICommodityDao();			
		Boolean result = iCommodityDao.purchase(commodityPurchaseDialog.commodityPanel.mainFram.user, commodityPurchaseDialog.commodity.getId(), Integer.parseInt(textField.getText()));
		if (result) {			
			commodityPurchaseDialog.commodityPanel.mainFram.user.setBalance(commodityPurchaseDialog.commodityPanel.mainFram.user.getBalance() - Integer.parseInt(textField.getText()) * commodityPurchaseDialog.commodity.getPrice());
			commodityPurchaseDialog.commodityPanel.mainFram.userPanel.creatUserInfo();
			commodityPurchaseDialog.commodityPanel.remove(commodityPurchaseDialog.commodityPanel.scrollPane);
			commodityPurchaseDialog.commodityPanel.creatList();		
			JOptionPane.showMessageDialog(commodityPurchaseDialog, "����ɹ����Ժ������������");
			commodityPurchaseDialog.dispose();
		}
		else {
			JOptionPane.showMessageDialog(commodityPurchaseDialog, "����ʧ�ܣ�������������");
		}
	}

}
