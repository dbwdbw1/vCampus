package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import vCampus.client.view.LoginDialog;
import vCampus.client.view.RegistDialog;

public class RegistBAction implements ActionListener {
	
	private LoginDialog logindialog;
	
	public RegistBAction(LoginDialog dialog) {
		this.logindialog = dialog;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		logindialog.registDialog = new RegistDialog(logindialog);
		logindialog.registDialog.setVisible(true);
	}

}
