package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.IBookDao;
import vCampus.client.view.BookPanel;
import vCampus.common.baseClass.Book;

public class BookRetreatAction implements ActionListener {
	
	private BookPanel bookPanel;
	private Book book;
	
	public BookRetreatAction(BookPanel bookPanel, Book book) {
		this.bookPanel = bookPanel;
		this.book = book;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		IBookDao iBookDao = new IBookDao();
		Boolean result = iBookDao.retreat(bookPanel.mainFram.user, book.getId());
		if (result) {
			for(int i = 0; i < bookPanel.mainFram.user.getBookInfo().size(); i++){
				if (bookPanel.mainFram.user.getBookInfo().get(i).toString().equals(book.getId())) {
					bookPanel.mainFram.user.getBookInfo().remove(i);
					break;
				}
			}
			bookPanel.mainFram.userPanel.creatUserInfo();
			
			bookPanel.remove(bookPanel.scrollPane);
			bookPanel.creatList();
			
			JOptionPane.showMessageDialog(bookPanel.mainFram, "�˻��ɹ�");
		}
		else {
			JOptionPane.showMessageDialog(bookPanel.mainFram, "�˻�ʧ�ܣ�������������");
		}
	}

}
