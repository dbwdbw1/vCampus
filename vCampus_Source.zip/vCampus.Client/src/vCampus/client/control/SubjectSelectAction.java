package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import vCampus.client.dao.ISubjectDao;
import vCampus.client.view.SubjectPanel;

public class SubjectSelectAction implements ActionListener {
	private SubjectPanel subjectPanel;
	
	public SubjectSelectAction(SubjectPanel subjectPanel) {
		this.subjectPanel = subjectPanel;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		ISubjectDao iSubjectDao = new ISubjectDao();
		String id = subjectPanel.subjectTable.getValueAt(subjectPanel.subjectTable.getSelectedRow(), 0).toString();
		Boolean result = iSubjectDao.select(subjectPanel.mainFram.user, id);
		if (result) {
			subjectPanel.mainFram.user.getSubjectInfo().add(id);					
			subjectPanel.remove(subjectPanel.scrollPane);
			subjectPanel.creatList();
			JOptionPane.showMessageDialog(subjectPanel.mainFram, "ѡ�γɹ�");
		}
		else {
			JOptionPane.showMessageDialog(subjectPanel.mainFram, "ѡ��ʧ�ܣ�������������");
		}
	}

}
