package vCampus.client.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import vCampus.client.dao.IUserDao;
import vCampus.client.view.LoginDialog;

public class LoginAction implements ActionListener {
	
	private JTextField idField;
	private JPasswordField passwordField;
	private LoginDialog loginDialog;
	
	public LoginAction(JTextField textField, JPasswordField passwordField, LoginDialog dialog) {
		this.idField = textField;
		this.passwordField = passwordField;
		this.loginDialog = dialog;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		if (idField.getText() == null || idField.getText().equals("")) {
			JOptionPane.showMessageDialog(loginDialog, "�˺Ų���Ϊ��");
			return;
		}

		if (passwordField.getPassword() == null || passwordField.getPassword().length == 0) {
			JOptionPane.showMessageDialog(loginDialog, "���벻��Ϊ��");
			return;
		}
		
		IUserDao iUserDao = new IUserDao();
		
		loginDialog.mainFram.user = iUserDao.login(idField.getText(), String.valueOf(passwordField.getPassword()));
		
		if (loginDialog.mainFram.user == null) {
			JOptionPane.showMessageDialog(loginDialog, "��¼ʧ�ܣ������˻��������Ƿ���ȷ");
		}
		else {
			loginDialog.mainFram.creatComponent();
			loginDialog.mainFram.setVisible(true);
			loginDialog.dispose();
		}
	}

}
