package vCampus.client.control;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import vCampus.client.view.DormPanel;
import vCampus.common.baseClass.User;

public class DormListListenr implements ListSelectionListener {
	
	private User user;
	
	private DormPanel dormPanel;
	
	public DormListListenr( User user, DormPanel panel) {
		this.user = user;
		this.dormPanel = panel;
	}

	@Override
	public void valueChanged(ListSelectionEvent arg0) {
		if (user.getPower()) {
			if (dormPanel.dormTable.getValueAt(dormPanel.dormTable.getSelectedRow(), 6).equals("������Ӧ")) {
				dormPanel.stopButton.setEnabled(true);
			}
			else {
				dormPanel.stopButton.setEnabled(false);
			}
		}

	}

}
